#!/usr/bin/env bash
# Build Aurora as a native macOS .app bundle (Intel and Apple Silicon).
# Run from anywhere: scripts/build-macos-app.sh
set -euo pipefail

cd "$(dirname "$0")/.."

VERSION="$(sed -n 's/^version = "\(.*\)"/\1/p' Cargo.toml | head -1)"
export MACOSX_DEPLOYMENT_TARGET="${MACOSX_DEPLOYMENT_TARGET:-10.15}"

echo "==> Building Aurora $VERSION (release, deployment target $MACOSX_DEPLOYMENT_TARGET)"
cargo build --release

APP="dist/Aurora.app"
rm -rf "$APP"
mkdir -p "$APP/Contents/MacOS" "$APP/Contents/Resources"

cp "target/release/aurora" "$APP/Contents/MacOS/aurora"
chmod +x "$APP/Contents/MacOS/aurora"
cp assets/logo.png "$APP/Contents/Resources/logo.png"

# --- Icon ---------------------------------------------------------------
ICONSET="$(mktemp -d)/AppIcon.iconset"
mkdir -p "$ICONSET"
for size in 16 32 128 256 512; do
    sips -z "$size" "$size" assets/logo.png --out "$ICONSET/icon_${size}x${size}.png" >/dev/null
    double=$((size * 2))
    sips -z "$double" "$double" assets/logo.png --out "$ICONSET/icon_${size}x${size}@2x.png" >/dev/null
done
iconutil -c icns "$ICONSET" -o "$APP/Contents/Resources/AppIcon.icns"
rm -rf "$(dirname "$ICONSET")"

# --- Info.plist ---------------------------------------------------------
cat > "$APP/Contents/Info.plist" <<PLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>CFBundleName</key>
    <string>Aurora</string>
    <key>CFBundleDisplayName</key>
    <string>Aurora</string>
    <key>CFBundleIdentifier</key>
    <string>com.aurora.app</string>
    <key>CFBundleExecutable</key>
    <string>aurora</string>
    <key>CFBundleIconFile</key>
    <string>AppIcon</string>
    <key>CFBundlePackageType</key>
    <string>APPL</string>
    <key>CFBundleShortVersionString</key>
    <string>${VERSION}</string>
    <key>CFBundleVersion</key>
    <string>${VERSION}</string>
    <key>LSMinimumSystemVersion</key>
    <string>10.15</string>
    <key>NSHighResolutionCapable</key>
    <true/>
    <key>NSSupportsAutomaticGraphicsSwitching</key>
    <true/>
    <key>LSApplicationCategoryType</key>
    <string>public.app-category.games</string>
</dict>
</plist>
PLIST

# Ad-hoc signature keeps Gatekeeper and the Keychain happy for a local build.
codesign --force --deep --sign - "$APP" >/dev/null 2>&1 || true

echo
echo "Built: $APP"

# --- Install -------------------------------------------------------------
# Installs the app so you can open it like any other Mac app (Launchpad,
# Spotlight, Dock) instead of running this script each time.
# Set NO_INSTALL=1 to only build dist/Aurora.app.
if [[ "${NO_INSTALL:-0}" == "1" ]]; then
    echo "Skipping install (NO_INSTALL=1). Launch with: open \"$APP\""
    exit 0
fi

DEST_DIR="/Applications"
if [[ ! -w "$DEST_DIR" ]]; then
    DEST_DIR="$HOME/Applications"
    mkdir -p "$DEST_DIR"
fi
DEST="$DEST_DIR/Aurora.app"

# Quit a running copy first so the files can be replaced cleanly.
if pgrep -x aurora >/dev/null 2>&1; then
    echo "==> Closing the running Aurora"
    osascript -e 'tell application id "com.aurora.app" to quit' >/dev/null 2>&1 || true
    for _ in 1 2 3 4 5 6; do
        pgrep -x aurora >/dev/null 2>&1 || break
        sleep 0.5
    done
    pkill -x aurora >/dev/null 2>&1 || true
fi

rm -rf "$DEST"
ditto "$APP" "$DEST"
printf '%s' "$DEST" > dist/.installed_path

# Remember where this source folder lives so the next update zip can find it.
mkdir -p "$HOME/Library/Application Support/Aurora" 2>/dev/null || true
printf '%s' "$PWD" > "$HOME/Library/Application Support/Aurora/source-folder" 2>/dev/null || true

echo "==> Installed: $DEST"
echo "    Open it from Launchpad / Spotlight, or drag it to your Dock."
echo "    You only need to run this script again when you update the code."
