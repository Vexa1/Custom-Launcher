#!/usr/bin/env python3
"""Generate the app icon (assets/logo.png + assets/icon.ico).

The mark is a mint-to-violet aurora ribbon on a soft dark rounded square.
Drawing it with Pillow keeps it crisp and reproducible at every size, which
matters because the macOS bundle builds its .icns from this PNG.

Usage: python3 scripts/make-icon.py
"""

from PIL import Image, ImageDraw, ImageFilter
import math
import os

SIZE = 1024
SUPERSAMPLE = 2
S = SIZE * SUPERSAMPLE

OUT_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "assets")


def lerp(a, b, t):
    return tuple(round(a[i] + (b[i] - a[i]) * t) for i in range(3))


def gradient_color(t):
    stops = [
        (0.0, (96, 236, 186)),
        (0.45, (92, 190, 255)),
        (0.78, (150, 150, 255)),
        (1.0, (196, 158, 255)),
    ]
    for i in range(len(stops) - 1):
        t0, c0 = stops[i]
        t1, c1 = stops[i + 1]
        if t <= t1:
            local = 0.0 if t1 == t0 else (t - t0) / (t1 - t0)
            return lerp(c0, c1, max(0.0, min(1.0, local)))
    return stops[-1][1]


def rounded_background(size):
    img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    mask = Image.new("L", (size, size), 0)
    ImageDraw.Draw(mask).rounded_rectangle(
        [(0, 0), (size - 1, size - 1)], radius=int(size * 0.225), fill=255
    )
    # Subtle vertical gradient from near-black to a deep blue-grey.
    grad = Image.new("RGBA", (size, size))
    gd = ImageDraw.Draw(grad)
    top = (13, 16, 23)
    bottom = (26, 33, 48)
    for y in range(size):
        t = y / (size - 1)
        gd.line([(0, y), (size, y)], fill=lerp(top, bottom, t) + (255,))
    img.paste(grad, (0, 0), mask)
    return img


def bezier(p0, p1, p2, p3, t):
    u = 1.0 - t
    x = u**3 * p0[0] + 3 * u**2 * t * p1[0] + 3 * u * t**2 * p2[0] + t**3 * p3[0]
    y = u**3 * p0[1] + 3 * u**2 * t * p1[1] + 3 * u * t**2 * p2[1] + t**3 * p3[1]
    return (x, y)


def main():
    scale = SUPERSAMPLE
    base = rounded_background(S)

    p0 = (0.235 * S, 0.735 * S)
    p1 = (0.40 * S, 0.40 * S)
    p2 = (0.64 * S, 0.66 * S)
    p3 = (0.775 * S, 0.315 * S)

    ribbon = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    rd = ImageDraw.Draw(ribbon)
    steps = 900
    for i in range(steps + 1):
        t = i / steps
        x, y = bezier(p0, p1, p2, p3, t)
        # Thicker in the middle, tapering to both ends.
        r = (0.016 + 0.019 * math.sin(math.pi * t)) * S
        color = gradient_color(t) + (255,)
        rd.ellipse([(x - r, y - r), (x + r, y + r)], fill=color)

    glow = ribbon.filter(ImageFilter.GaussianBlur(radius=int(0.028 * S)))
    glow.putalpha(glow.getchannel("A").point(lambda v: int(v * 0.55)))
    base.alpha_composite(glow)
    base.alpha_composite(glow)
    sharp = ribbon.filter(ImageFilter.GaussianBlur(radius=max(1, int(0.0016 * S))))
    base.alpha_composite(sharp)

    # Leading star at the end of the ribbon.
    dot = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    dd = ImageDraw.Draw(dot)
    ex, ey = bezier(p0, p1, p2, p3, 1.0)
    r = 0.030 * S
    dd.ellipse([(ex - r, ey - r), (ex + r, ey + r)], fill=(255, 255, 255, 255))
    halo = dot.filter(ImageFilter.GaussianBlur(radius=int(0.026 * S)))
    halo.putalpha(halo.getchannel("A").point(lambda v: int(v * 0.8)))
    base.alpha_composite(halo)
    base.alpha_composite(dot)

    icon = base.resize((SIZE // (SUPERSAMPLE // scale) if False else SIZE, SIZE), Image.LANCZOS)

    os.makedirs(OUT_DIR, exist_ok=True)
    png_path = os.path.join(OUT_DIR, "logo.png")
    icon.resize((512, 512), Image.LANCZOS).save(png_path, "PNG")

    ico_path = os.path.join(OUT_DIR, "icon.ico")
    icon.save(ico_path, sizes=[(16, 16), (24, 24), (32, 32), (48, 48), (64, 64), (128, 128), (256, 256)])

    print(f"wrote {png_path} and {ico_path}")


if __name__ == "__main__":
    main()
