//! macOS menu-bar (status item) tray, login item and single-instance support.
//!
//! The status item and its menu are created on the main thread, inside
//! `TrayController::new`, which eframe calls while starting the AppKit event
//! loop. Menu clicks are forwarded to the app over the existing `Msg` channel.

use std::env;
use std::fs;
use std::path::{Path, PathBuf};
use std::process::Command;
use std::sync::mpsc::Sender;
use std::sync::{Arc, Mutex};
use std::thread::{self, JoinHandle};
use std::time::Duration;

use eframe::egui;
use tray_icon::menu::{CheckMenuItem, Menu, MenuItem, PredefinedMenuItem};
use tray_icon::{
    Icon, MouseButton, MouseButtonState, TrayIcon, TrayIconBuilder, TrayIconEvent,
};

use crate::types::Msg;

const ITEM_SHOW: &str = "aurora.show";
const ITEM_HIDE: &str = "aurora.hide";
const ITEM_HOME: &str = "aurora.home";
const ITEM_PROFILE: &str = "aurora.profile";
const ITEM_AVATAR: &str = "aurora.avatar";
const ITEM_NOTIFICATIONS: &str = "aurora.notifications";
const ITEM_SETTINGS: &str = "aurora.settings";
const ITEM_FASTFLAGS: &str = "aurora.fastflags";
const ITEM_TOGGLE_SERVER: &str = "aurora.overlay.server";
const ITEM_TOGGLE_STATS: &str = "aurora.overlay.stats";
const ITEM_TOGGLE_CROSSHAIR: &str = "aurora.overlay.crosshair";
const ITEM_COPY_JOB: &str = "aurora.copy_job";
const ITEM_DISCORD: &str = "aurora.discord";
const ITEM_UPDATES: &str = "aurora.updates";
const ITEM_QUIT: &str = "aurora.quit";

const LAUNCH_AGENT_LABEL: &str = "com.aurora.launcher";

#[derive(Clone, Debug, PartialEq, Eq)]
pub enum TrayEvent {
    ShowAndFocus,
    HideToTray,
    OpenHome,
    OpenProfile,
    OpenAvatar,
    OpenNotifications,
    OpenSettings,
    OpenFastFlags,
    ToggleServerOverlay,
    ToggleStatsOverlay,
    ToggleCrosshair,
    CopyJobId,
    ToggleDiscordRpc,
    CheckUpdates,
    QuitApp,
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct TrayState {
    pub enabled: bool,
    pub window_visible: bool,
    pub status_line: String,
    pub tooltip: String,
    pub discord_rpc_enabled: bool,
    /// Signed in: the page shortcuts (Home, Profile, …) can be used.
    pub signed_in: bool,
    /// "Server: Dallas, US" while connected, empty otherwise.
    pub server_line: String,
    /// Roblox Job ID of the current server, empty when unknown.
    pub job_id: String,
    pub overlay_server: bool,
    pub overlay_stats: bool,
    pub overlay_crosshair: bool,
}

impl Default for TrayState {
    fn default() -> Self {
        Self {
            enabled: true,
            window_visible: true,
            status_line: "Idle".to_string(),
            tooltip: "Aurora".to_string(),
            discord_rpc_enabled: true,
            signed_in: false,
            server_line: String::new(),
            job_id: String::new(),
            overlay_server: true,
            overlay_stats: false,
            overlay_crosshair: false,
        }
    }
}

struct TrayShared {
    desired: TrayState,
    shutdown: bool,
}

pub struct TrayController {
    icon: Mutex<Option<TrayIcon>>,
    show_item: MenuItem,
    hide_item: MenuItem,
    page_items: Vec<MenuItem>,
    status_item: MenuItem,
    server_item: MenuItem,
    copy_job_item: MenuItem,
    server_overlay_item: CheckMenuItem,
    stats_overlay_item: CheckMenuItem,
    crosshair_item: CheckMenuItem,
    discord_item: CheckMenuItem,
    shared: Arc<Mutex<TrayShared>>,
    join: Mutex<Option<JoinHandle<()>>>,
}

impl TrayController {
    pub fn new(initial: TrayState, tx: Sender<Msg>, ctx: egui::Context) -> Self {
        let shared = Arc::new(Mutex::new(TrayShared {
            desired: initial.clone(),
            shutdown: false,
        }));

        let show_item = MenuItem::with_id(ITEM_SHOW, "Open Aurora", true, None);
        let hide_item = MenuItem::with_id(ITEM_HIDE, "Hide to Menu Bar", true, None);
        let home_item = MenuItem::with_id(ITEM_HOME, "Home", true, None);
        let profile_item = MenuItem::with_id(ITEM_PROFILE, "Profile", true, None);
        let avatar_item = MenuItem::with_id(ITEM_AVATAR, "Avatar", true, None);
        let notifications_item =
            MenuItem::with_id(ITEM_NOTIFICATIONS, "Notifications", true, None);
        let settings_item = MenuItem::with_id(ITEM_SETTINGS, "Settings…", true, None);
        let fastflags_item = MenuItem::with_id(ITEM_FASTFLAGS, "FastFlags…", true, None);
        let status_item = MenuItem::with_id("aurora.status", initial.status_line.clone(), false, None);
        let server_item = MenuItem::with_id("aurora.server", "Server: not connected", false, None);
        let copy_job_item =
            MenuItem::with_id(ITEM_COPY_JOB, "Copy Job ID", !initial.job_id.is_empty(), None);
        let server_overlay_item = CheckMenuItem::with_id(
            ITEM_TOGGLE_SERVER,
            "Server region overlay",
            true,
            initial.overlay_server,
            None,
        );
        let stats_overlay_item = CheckMenuItem::with_id(
            ITEM_TOGGLE_STATS,
            "Stats overlay",
            true,
            initial.overlay_stats,
            None,
        );
        let crosshair_item = CheckMenuItem::with_id(
            ITEM_TOGGLE_CROSSHAIR,
            "Crosshair",
            true,
            initial.overlay_crosshair,
            None,
        );
        let discord_item = CheckMenuItem::with_id(
            ITEM_DISCORD,
            "Discord Rich Presence",
            true,
            initial.discord_rpc_enabled,
            None,
        );
        let updates_item = MenuItem::with_id(ITEM_UPDATES, "Check for Updates…", true, None);
        let quit_item = MenuItem::with_id(ITEM_QUIT, "Quit Aurora", true, None);
        let sep1 = PredefinedMenuItem::separator();
        let sep2 = PredefinedMenuItem::separator();
        let sep3 = PredefinedMenuItem::separator();
        let sep4 = PredefinedMenuItem::separator();

        let icon = (|| -> Option<TrayIcon> {
            let menu = Menu::with_items(&[
                &show_item,
                &hide_item,
                &sep1,
                &home_item,
                &profile_item,
                &avatar_item,
                &notifications_item,
                &settings_item,
                &fastflags_item,
                &sep2,
                &status_item,
                &server_item,
                &copy_job_item,
                &sep3,
                &server_overlay_item,
                &stats_overlay_item,
                &crosshair_item,
                &discord_item,
                &updates_item,
                &sep4,
                &quit_item,
            ])
            .ok()?;
            TrayIconBuilder::new()
                .with_menu(Box::new(menu))
                .with_menu_on_left_click(false)
                .with_tooltip("Aurora")
                .with_icon(load_tray_icon()?)
                .build()
                .ok()
        })();

        if let Some(icon) = &icon {
            let _ = icon.set_visible(initial.enabled);
        }

        let shared_bg = Arc::clone(&shared);
        let join = thread::Builder::new()
            .name("aurora-tray".to_string())
            .spawn(move || {
                loop {
                    let shutdown = shared_bg
                        .lock()
                        .map(|g| g.shutdown)
                        .unwrap_or(true);
                    if shutdown {
                        break;
                    }
                    let mut fired = false;
                    while let Ok(ev) = tray_icon::menu::MenuEvent::receiver().try_recv() {
                        let id: &str = ev.id().as_ref();
                        let mapped = match id {
                            ITEM_SHOW => Some(TrayEvent::ShowAndFocus),
                            ITEM_HIDE => Some(TrayEvent::HideToTray),
                            ITEM_HOME => Some(TrayEvent::OpenHome),
                            ITEM_PROFILE => Some(TrayEvent::OpenProfile),
                            ITEM_AVATAR => Some(TrayEvent::OpenAvatar),
                            ITEM_NOTIFICATIONS => Some(TrayEvent::OpenNotifications),
                            ITEM_SETTINGS => Some(TrayEvent::OpenSettings),
                            ITEM_FASTFLAGS => Some(TrayEvent::OpenFastFlags),
                            ITEM_TOGGLE_SERVER => Some(TrayEvent::ToggleServerOverlay),
                            ITEM_TOGGLE_STATS => Some(TrayEvent::ToggleStatsOverlay),
                            ITEM_TOGGLE_CROSSHAIR => Some(TrayEvent::ToggleCrosshair),
                            ITEM_COPY_JOB => Some(TrayEvent::CopyJobId),
                            ITEM_DISCORD => Some(TrayEvent::ToggleDiscordRpc),
                            ITEM_UPDATES => Some(TrayEvent::CheckUpdates),
                            ITEM_QUIT => Some(TrayEvent::QuitApp),
                            _ => None,
                        };
                        if let Some(action) = mapped {
                            let _ = tx.send(Msg::TrayAction(action));
                            fired = true;
                        }
                    }
                    while let Ok(ev) = TrayIconEvent::receiver().try_recv() {
                        if let TrayIconEvent::Click {
                            button: MouseButton::Left,
                            button_state: MouseButtonState::Up,
                            ..
                        } = ev
                        {
                            let _ = tx.send(Msg::TrayAction(TrayEvent::ShowAndFocus));
                            fired = true;
                        }
                    }
                    if fired {
                        ctx.request_repaint();
                    }
                    thread::sleep(Duration::from_millis(200));
                }
            })
            .ok();

        Self {
            icon: Mutex::new(icon),
            show_item,
            hide_item,
            page_items: vec![
                home_item,
                profile_item,
                avatar_item,
                notifications_item,
                settings_item,
                fastflags_item,
            ],
            status_item,
            server_item,
            copy_job_item,
            server_overlay_item,
            stats_overlay_item,
            crosshair_item,
            discord_item,
            shared,
            join: Mutex::new(join),
        }
    }

    pub fn sync(&self, mut next: TrayState) {
        next.tooltip = clamp_tray_tooltip(&next.tooltip);
        let changed = {
            let Ok(mut guard) = self.shared.lock() else {
                return;
            };
            if guard.shutdown || guard.desired == next {
                false
            } else {
                guard.desired = next.clone();
                true
            }
        };
        if !changed {
            return;
        }
        if let Ok(guard) = self.icon.lock() {
            if let Some(icon) = guard.as_ref() {
                let _ = icon.set_visible(next.enabled);
                let _ = icon.set_tooltip(Some(next.tooltip.as_str()));
            }
        }
        self.discord_item.set_checked(next.discord_rpc_enabled);
        self.discord_item.set_enabled(next.enabled);
        self.server_overlay_item.set_checked(next.overlay_server);
        self.server_overlay_item.set_enabled(next.enabled);
        self.stats_overlay_item.set_checked(next.overlay_stats);
        self.stats_overlay_item.set_enabled(next.enabled);
        self.crosshair_item.set_checked(next.overlay_crosshair);
        self.crosshair_item.set_enabled(next.enabled);
        for item in &self.page_items {
            item.set_enabled(next.enabled && next.signed_in);
        }
        self.status_item.set_text(next.status_line.clone());
        self.server_item.set_text(if next.server_line.is_empty() {
            "Server: not connected".to_string()
        } else {
            next.server_line.clone()
        });
        self.copy_job_item.set_enabled(!next.job_id.is_empty());
        self.hide_item.set_enabled(next.enabled && next.window_visible);
        // Always usable: with Roblox fullscreen the window can be "visible" yet behind the
        // game, and clicking this raises Aurora over it.
        self.show_item.set_enabled(next.enabled);
        if next.window_visible {
            self.show_item.set_text("Open Aurora");
        } else {
            self.show_item
                .set_text(format!("Open Aurora — {}", next.status_line));
        }
    }

    pub fn show_balloon(&self, title: &str, body: &str) {
        let enabled = self
            .shared
            .lock()
            .map(|g| !g.shutdown && g.desired.enabled)
            .unwrap_or(false);
        if !enabled {
            return;
        }
        let script = format!(
            "display notification {} with title {}",
            applescript_string(body),
            applescript_string(title)
        );
        let _ = Command::new("/usr/bin/osascript")
            .args(["-e", &script])
            .spawn();
    }

    pub fn shutdown(&self) {
        {
            if let Ok(mut guard) = self.shared.lock() {
                guard.shutdown = true;
                guard.desired.enabled = false;
            }
        }
        if let Ok(mut slot) = self.icon.lock() {
            slot.take();
        }
        if let Ok(mut slot) = self.join.lock() {
            if let Some(handle) = slot.take() {
                let _ = handle.join();
            }
        }
    }
}

impl Drop for TrayController {
    fn drop(&mut self) {
        self.shutdown();
    }
}

fn applescript_string(raw: &str) -> String {
    let escaped = raw
        .replace('\\', "\\\\")
        .replace('"', "\\\"")
        .replace('\n', " ");
    format!("\"{escaped}\"")
}

fn load_tray_icon() -> Option<Icon> {
    let img = image::load_from_memory(include_bytes!("../assets/logo.png")).ok()?;
    let resized = image::imageops::resize(
        &img.to_rgba8(),
        22,
        22,
        image::imageops::FilterType::Lanczos3,
    );
    let (w, h) = resized.dimensions();
    Icon::from_rgba(resized.into_raw(), w, h).ok()
}

// ---------------------------------------------------------------------------
// Bring the launcher to the front, even while Roblox is fullscreen
// ---------------------------------------------------------------------------

#[link(name = "objc")]
unsafe extern "C" {
    fn objc_getClass(name: *const std::ffi::c_char) -> *mut std::ffi::c_void;
    fn sel_registerName(name: *const std::ffi::c_char) -> *mut std::ffi::c_void;
    fn objc_msgSend();
}

/// Makes Aurora the active app. Without this, clicking the menu bar while Roblox
/// owns the screen (especially a fullscreen Space) can leave the launcher behind
/// the game; `activateIgnoringOtherApps` switches to Aurora's Space.
pub fn activate_app() {
    use std::ffi::CString;
    use std::os::raw::c_void;
    type Msg0 = unsafe extern "C" fn(*mut c_void, *mut c_void) -> *mut c_void;
    type Msg1 = unsafe extern "C" fn(*mut c_void, *mut c_void, isize) -> *mut c_void;

    unsafe {
        let class = objc_getClass(c"NSApplication".as_ptr());
        if class.is_null() {
            return;
        }
        let Ok(sel_shared) = CString::new("sharedApplication") else {
            return;
        };
        let shared: Msg0 = std::mem::transmute(objc_msgSend as unsafe extern "C" fn());
        let app = shared(class, sel_registerName(sel_shared.as_ptr()));
        if app.is_null() {
            return;
        }
        let Ok(sel_activate) = CString::new("activateIgnoringOtherApps:") else {
            return;
        };
        let activate: Msg1 = std::mem::transmute(objc_msgSend as unsafe extern "C" fn());
        activate(app, sel_registerName(sel_activate.as_ptr()), 1);

        // Activation alone can leave the launcher window hidden behind Roblox (or still
        // ordered out after "hide to menu bar"), so raise every window explicitly.
        let Ok(sel_windows) = CString::new("windows") else {
            return;
        };
        let windows: Msg0 = std::mem::transmute(objc_msgSend as unsafe extern "C" fn());
        let list = windows(app, sel_registerName(sel_windows.as_ptr()));
        if list.is_null() {
            return;
        }
        let Ok(sel_count) = CString::new("count") else {
            return;
        };
        let count = windows(list, sel_registerName(sel_count.as_ptr())) as usize;
        let Ok(sel_at) = CString::new("objectAtIndex:") else {
            return;
        };
        let Ok(sel_front) = CString::new("makeKeyAndOrderFront:") else {
            return;
        };
        let object_at: Msg1 = std::mem::transmute(objc_msgSend as unsafe extern "C" fn());
        for i in 0..count {
            let window = object_at(list, sel_registerName(sel_at.as_ptr()), i as isize);
            if window.is_null() {
                continue;
            }
            activate(window, sel_registerName(sel_front.as_ptr()), 0);
        }
    }
}

pub fn clamp_tray_tooltip(raw: &str) -> String {
    let trimmed = raw.trim();
    let src = if trimmed.is_empty() {
        "Aurora"
    } else {
        trimmed
    };
    // macOS tooltips are short; keep a tidy single line.
    let mut out: String = src.chars().take(96).collect();
    if out.trim().is_empty() {
        out = "Aurora".to_string();
    }
    out
}

pub fn should_start_in_tray(args: &[String], tray_enabled: bool) -> bool {
    tray_enabled
        && args.iter().skip(1).any(|a| {
            matches!(
                a.trim().to_ascii_lowercase().as_str(),
                "--tray" | "--minimized" | "--start-minimized"
            )
        })
}

pub fn build_startup_command(exe_path: &Path, start_minimized: bool) -> String {
    if start_minimized {
        format!("\"{}\" --tray", exe_path.display())
    } else {
        format!("\"{}\"", exe_path.display())
    }
}

pub fn parse_startup_command(cmd: &str) -> Option<(String, bool)> {
    let trimmed = cmd.trim();
    if trimmed.is_empty() {
        return None;
    }
    let (exe, rest) = if let Some(after_quote) = trimmed.strip_prefix('"') {
        let end = after_quote.find('"')?;
        (&after_quote[..end], &after_quote[end + 1..])
    } else {
        match trimmed.find(char::is_whitespace) {
            Some(idx) => (&trimmed[..idx], &trimmed[idx..]),
            None => (trimmed, ""),
        }
    };
    if exe.is_empty() {
        return None;
    }
    let minimized = rest.split_whitespace().any(|flag| {
        matches!(
            flag.to_ascii_lowercase().as_str(),
            "--tray" | "--minimized" | "--start-minimized"
        )
    });
    Some((exe.to_string(), minimized))
}

fn launch_agent_path() -> Option<PathBuf> {
    Some(
        PathBuf::from(env::var("HOME").ok()?)
            .join("Library")
            .join("LaunchAgents")
            .join(format!("{LAUNCH_AGENT_LABEL}.plist")),
    )
}

fn xml_escape(raw: &str) -> String {
    raw.replace('&', "&amp;")
        .replace('<', "&lt;")
        .replace('>', "&gt;")
        .replace('"', "&quot;")
}

fn launch_agent_plist(exe: &Path, start_minimized: bool) -> String {
    let mut args = format!(
        "        <string>{}</string>\n",
        xml_escape(&exe.display().to_string())
    );
    if start_minimized {
        args.push_str("        <string>--tray</string>\n");
    }
    format!(
        "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n\
<!DOCTYPE plist PUBLIC \"-//Apple//DTD PLIST 1.0//EN\" \"http://www.apple.com/DTDs/PropertyList-1.0.dtd\">\n\
<plist version=\"1.0\">\n\
<dict>\n\
    <key>Label</key>\n\
    <string>{LAUNCH_AGENT_LABEL}</string>\n\
    <key>ProgramArguments</key>\n\
    <array>\n{args}    </array>\n\
    <key>RunAtLoad</key>\n\
    <true/>\n\
    <key>KeepAlive</key>\n\
    <false/>\n\
    <key>ProcessType</key>\n\
    <string>Interactive</string>\n\
</dict>\n\
</plist>\n"
    )
}

pub fn is_startup_enabled() -> bool {
    launch_agent_path().is_some_and(|p| p.exists())
}

pub fn set_startup(enabled: bool, start_minimized: bool) -> Result<(), String> {
    let path = launch_agent_path().ok_or_else(|| "Could not find home folder".to_string())?;
    if !enabled {
        if path.exists() {
            fs::remove_file(&path).map_err(|e| e.to_string())?;
        }
        return Ok(());
    }
    let exe = env::current_exe().map_err(|e| e.to_string())?;
    if let Some(dir) = path.parent() {
        fs::create_dir_all(dir).map_err(|e| e.to_string())?;
    }
    fs::write(&path, launch_agent_plist(&exe, start_minimized)).map_err(|e| e.to_string())
}

pub fn sync_startup_path_if_enabled(start_minimized: bool) {
    if !is_startup_enabled() {
        return;
    }
    let Ok(exe) = env::current_exe() else {
        return;
    };
    let Some(path) = launch_agent_path() else {
        return;
    };
    let desired = launch_agent_plist(&exe, start_minimized);
    if fs::read_to_string(&path).ok().as_deref() != Some(desired.as_str()) {
        let _ = fs::write(path, desired);
    }
}

/// A second copy of Aurora should hand off to the running instance instead of
/// opening a duplicate window. `flock` gives us a cheap process-lifetime lock.
pub fn try_focus_existing_instance() -> bool {
    use std::fs::OpenOptions;
    use std::os::unix::io::AsRawFd;

    let path = crate::auth::data_dir().join(".instance.lock");
    let Ok(file) = OpenOptions::new()
        .create(true)
        .read(true)
        .write(true)
        .truncate(false)
        .open(&path)
    else {
        return false;
    };
    let rc = unsafe { libc::flock(file.as_raw_fd(), libc::LOCK_EX | libc::LOCK_NB) };
    if rc == 0 {
        // Hold the lock for the rest of the process lifetime.
        std::mem::forget(file);
        return false;
    }
    // Another instance owns it: try to bring it forward.
    let _ = Command::new("/usr/bin/osascript")
        .args([
            "-e",
            "tell application \"System Events\" to set frontmost of (first process whose name is \"aurora\") to true",
        ])
        .status();
    true
}
