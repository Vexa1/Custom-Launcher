use crate::app::Creblox;
use crate::auth::{data_dir, save_settings, write_ids};
use crate::fastflags::{
    LightingMode, RendererMode, export_effective_flags_json, format_flag_value,
    import_custom_flags_json, parse_flag_value, save_fastflags, sync_client_fastflags,
};
use crate::roblox_process::{
    apply_fps_setting, close_tray_roblox_processes, find_player, handler_status, register, restore,
};
use crate::theme::{
    BLUE, GREEN, ORANGE, Palette, RED, accent_color, apply_theme, card_frame, effective_dark_mode,
    is_dark_color, pal,
};
use crate::tray::set_startup;
use crate::types::{Action, BgMode, Settings, TextColorMode};
use crate::ui::page_login::draw_login_marquee;
use crate::ui::widgets::*;
use crate::updater::{CREBLOX_RELEASES_URL, UpdateKind};
use eframe::egui::{self, Color32, CornerRadius, RichText, Sense};
use std::sync::atomic::Ordering;

#[derive(Clone, Copy)]
struct ThemePack {
    name: &'static str,
    dark: bool,
    bg_mode: BgMode,
    bg_color: [u8; 3],
    text_mode: TextColorMode,
    borders: Option<[u8; 3]>,
    profile: Option<[u8; 3]>,
    friends: Option<[u8; 3]>,
    games: Option<[u8; 3]>,
    text_border: Option<[u8; 3]>,
    preview_accent: [u8; 3],
}

/// Left-to-right order of the settings rail.
const SETTINGS_SECTIONS: [&str; 9] = [
    "Accounts",
    "Appearance",
    "Performance",
    "Overlay",
    "FastFlags",
    "Tray",
    "Discord",
    "Updates",
    "Logs",
];

const THEME_PACKS: [ThemePack; 6] = [
    ThemePack {
        name: "Light",
        dark: false,
        bg_mode: BgMode::ThemeDefault,
        bg_color: [248, 249, 250],
        text_mode: TextColorMode::Auto,
        borders: None,
        profile: None,
        friends: None,
        games: None,
        text_border: None,
        preview_accent: [0, 148, 255],
    },
    ThemePack {
        name: "Dark",
        dark: true,
        bg_mode: BgMode::ThemeDefault,
        bg_color: [17, 19, 24],
        text_mode: TextColorMode::Auto,
        borders: None,
        profile: None,
        friends: None,
        games: None,
        text_border: None,
        preview_accent: [0, 176, 111],
    },
    ThemePack {
        name: "Mint",
        dark: true,
        bg_mode: BgMode::SolidColor,
        bg_color: [14, 22, 30],
        text_mode: TextColorMode::Auto,
        borders: Some([34, 197, 148]),
        profile: Some([0, 214, 143]),
        friends: Some([56, 224, 168]),
        games: Some([28, 170, 132]),
        text_border: Some([48, 210, 160]),
        preview_accent: [0, 214, 143],
    },
    ThemePack {
        name: "Rose",
        dark: true,
        bg_mode: BgMode::SolidColor,
        bg_color: [56, 18, 34],
        text_mode: TextColorMode::Auto,
        borders: Some([232, 92, 142]),
        profile: Some([255, 118, 168]),
        friends: Some([248, 138, 180]),
        games: Some([212, 76, 128]),
        text_border: Some([244, 122, 168]),
        preview_accent: [255, 118, 168],
    },
    ThemePack {
        name: "Ocean",
        dark: true,
        bg_mode: BgMode::SolidColor,
        bg_color: [14, 28, 48],
        text_mode: TextColorMode::Auto,
        borders: Some([62, 162, 240]),
        profile: Some([76, 194, 255]),
        friends: Some([96, 210, 255]),
        games: Some([52, 146, 224]),
        text_border: Some([86, 188, 255]),
        preview_accent: [76, 194, 255],
    },
    ThemePack {
        name: "Sand",
        dark: false,
        bg_mode: BgMode::SolidColor,
        bg_color: [244, 237, 226],
        text_mode: TextColorMode::Auto,
        borders: Some([178, 156, 130]),
        profile: Some([152, 124, 94]),
        friends: Some([134, 156, 118]),
        games: Some([168, 144, 118]),
        text_border: Some([154, 132, 106]),
        preview_accent: [152, 124, 94],
    },
];

/// Bytes as a short human string for the cache readout: `912 B`, `41.2 KB`, `17.3 MB`.
fn cache_size(bytes: usize) -> String {
    const KB: f64 = 1024.0;
    const MB: f64 = KB * 1024.0;
    let b = bytes as f64;
    if b >= MB {
        format!("{:.1} MB", b / MB)
    } else if b >= KB {
        format!("{:.1} KB", b / KB)
    } else {
        format!("{bytes} B")
    }
}

impl Creblox {
    pub fn page_settings(&mut self, ui: &mut egui::Ui, acts: &mut Vec<Action>) {
        let p = pal(ui);
        ui.add_space(12.0);
        ui.label(RichText::new("Settings").size(26.0).strong());
        ui.add_space(10.0);

        let mut section = (self.settings_section as usize).min(SETTINGS_SECTIONS.len() - 1);

        ui.vertical(|ui| {
            ui.set_max_width(740.0);

            // A newer build owns this settings.json: this build's keys are merged into it and
            // its own settings are kept, so say that here and not only in the log.
            if let Some(version) = crate::auth::newer_settings_file() {
                card_frame(ui, 12).show(ui, |ui| {
                    ui.set_width(ui.available_width());
                    ui.label(
                        RichText::new(format!("Settings file from a newer CREBLOX (v{version})"))
                            .size(13.0)
                            .strong()
                            .color(crate::theme::warning_ink(ui.visuals().dark_mode)),
                    );
                    ui.add_space(2.0);
                    small_text(
                        ui,
                        "Changes you make here are saved into it; its other settings are left \
                         untouched."
                            .to_string(),
                    );
                });
                ui.add_space(10.0);
            }

            // Section rail: one click swaps the page between groups, so nothing has to be
            // hunted for in one long scroll.
            ui.horizontal_wrapped(|ui| {
                ui.spacing_mut().item_spacing = egui::vec2(7.0, 7.0);
                for (i, label) in SETTINGS_SECTIONS.iter().enumerate() {
                    let active = section == i;
                    let btn = egui::Button::new(
                        RichText::new(*label).size(13.0).strong().color(if active {
                            Color32::from_rgb(16, 19, 26)
                        } else {
                            p.text
                        }),
                    )
                    .fill(if active { accent_color(ui) } else { p.surface_bg })
                    .corner_radius(16);
                    if ui.add(btn).clicked() {
                        section = i;
                        // Clicking the section you are already in jumps back to the top.
                        self.scroll_to_top = true;
                    }
                }
            });
            ui.add_space(12.0);

            if section == 0 {
            // Accounts card
            card_frame(ui, 18).show(ui, |ui| {
                ui.set_width(ui.available_width());
                ui.horizontal(|ui| {
                    ui.label(RichText::new("Accounts").size(17.0).strong());
                    ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
                        if ui.button("+ Add account").clicked() {
                            acts.push(Action::AddAccount);
                        }
                        if self.cookie.is_some() {
                            if ui.button("Sign out").clicked() {
                                self.sign_out();
                            }
                            if ui.button("Refresh").clicked() {
                                self.sync_auth_session(true);
                                self.status = "Refreshing profile & friends...".to_string();
                            }
                        }
                    });
                });
                ui.add_space(6.0);

                if !self.saved_accounts.is_empty() {
                    let active_id = self.me.as_ref().map(|m| m.user.id);
                    let saved = self.saved_accounts.clone();
                    for acc in &saved {
                        let is_active = active_id == Some(acc.id)
                            || self.cookie.as_deref() == Some(acc.cookie.as_str());
                        egui::Frame::new()
                            .fill(if is_active {
                                p.selected_bg.gamma_multiply(0.35)
                            } else {
                                p.surface_bg
                            })
                            .stroke(egui::Stroke::new(1.0, p.border))
                            .corner_radius(8)
                            .inner_margin(egui::Margin::symmetric(10, 7))
                            .show(ui, |ui| {
                                ui.horizontal(|ui| {
                                    let _ = thumb_styled(
                                        ui,
                                        Some(&acc.headshot),
                                        egui::vec2(28.0, 28.0),
                                        14,
                                        true,
                                    );
                                    ui.add_space(4.0);
                                    ui.vertical(|ui| {
                                        ui.spacing_mut().item_spacing.y = 0.0;
                                        ui.horizontal(|ui| {
                                            ui.label(RichText::new(&acc.display).size(13.0).strong());
                                            if acc.verified {
                                                verified_badge_tip(ui, 12.5, "Verified Account");
                                            }
                                            if is_active {
                                                ui.label(RichText::new("• Active").size(11.5).color(GREEN));
                                            }
                                        });
                                        small_text(ui, format!("@{}", acc.name));
                                    });
                                    ui.with_layout(
                                        egui::Layout::right_to_left(egui::Align::Center),
                                        |ui| {
                                            if ui.button(RichText::new("Remove").size(11.5).color(RED)).clicked() {
                                                acts.push(Action::RemoveAccount(acc.id));
                                            }
                                            if !is_active && ui.button("Switch").clicked() {
                                                acts.push(Action::SwitchAccount(acc.id));
                                            }
                                        },
                                    );
                                });
                            });
                        ui.add_space(5.0);
                    }
                } else if self.cookie.is_none() {
                    ui.label(RichText::new("Not signed in.").color(p.muted));
                    ui.add_space(6.0);
                    if ui.button("Sign in with Quick Login").clicked() {
                        acts.push(Action::StartQuickLogin);
                    }
                }
            });

            }

            ui.add_space(12.0);

            // CREBLOX Self-Updater card
            if section == 7 {
                self.settings_updates_card(ui, acts);
            }

            ui.add_space(12.0);

            // Theme & Background card
            if section == 1 {
                self.settings_theme_card(ui);
            }

            ui.add_space(12.0);

            // Roblox Client & Performance card
            if section == 2 {
            card_frame(ui, 18).show(ui, |ui| {
                ui.set_width(ui.available_width());
                ui.label(RichText::new("Roblox Client & Performance").size(17.0).strong());
                ui.add_space(8.0);
                let prev_fps = self.settings.target_fps;
                let fps_label = |fps: Option<u32>| match fps {
                    None => "Default".to_string(),
                    Some(999) => "999 FPS (Unlimited)".to_string(),
                    Some(n) => format!("{n} FPS"),
                };
                ui.horizontal(|ui| {
                    ui.label("Target FPS limit:");
                    egui::ComboBox::from_id_salt("target_fps")
                        .selected_text(fps_label(self.settings.target_fps))
                        .show_ui(ui, |ui| {
                            for opt in [None, Some(60), Some(120), Some(144), Some(240), Some(999)] {
                                ui.selectable_value(&mut self.settings.target_fps, opt, fps_label(opt));
                            }
                        });
                });
                if self.settings.target_fps != prev_fps {
                    save_settings(&self.settings);
                    self.player_path = find_player();
                    self.status = match apply_fps_setting(self.settings.target_fps) {
                        Ok(()) => format!("Target FPS set to {}", fps_label(self.settings.target_fps)),
                        Err(e) => format!("Saved preference, but {e}"),
                    };
                }
                ui.add_space(4.0);
                small_text(
                    ui,
                    "Writes DFIntTaskSchedulerTargetFps to Roblox's ClientAppSettings.json (applied on launch)."
                        .to_string(),
                );

                ui.add_space(12.0);
                ui.separator();
                ui.add_space(10.0);

                // CREBLOX app RAM allocation & CPU limiter controls (also adjustable from left performance dock)
                let p = pal(ui);
                let accent = accent_color(ui);
                let accent_fg = if is_dark_color([accent.r(), accent.g(), accent.b()]) {
                    Color32::WHITE
                } else {
                    Color32::from_rgb(16, 19, 26)
                };
                let mut limits_changed = false;
                let mut trim_now = false;

                ui.horizontal(|ui| {
                    ui.label("Launcher RAM limit:");
                    let cur_txt = self
                        .settings
                        .ram_limit_mb
                        .map(|mb| format!("{mb} MB"))
                        .unwrap_or_else(|| "Auto".to_string());
                    ui.label(RichText::new(cur_txt).strong().color(accent));
                    if let Some(used_mb) = crate::telemetry::current_process_ram_mb() {
                        ui.label(
                            RichText::new(format!("(currently {used_mb:.0} MB)"))
                                .size(12.0)
                                .color(p.muted),
                        );
                    }
                });
                ui.horizontal_wrapped(|ui| {
                    ui.spacing_mut().item_spacing = egui::vec2(6.0, 6.0);
                    for (opt, lbl) in [
                        (None, "Auto"),
                        (Some(192), "192 MB"),
                        (Some(256), "256 MB"),
                        (Some(512), "512 MB"),
                        (Some(1024), "1024 MB"),
                    ] {
                        let sel = self.settings.ram_limit_mb == opt;
                        let btn = egui::Button::new(
                            RichText::new(lbl)
                                .size(12.0)
                                .strong()
                                .color(if sel { accent_fg } else { p.text }),
                        )
                        .fill(if sel { accent } else { p.surface_bg })
                        .corner_radius(7);
                        if ui.add(btn).clicked() && !sel {
                            self.settings.ram_limit_mb = opt;
                            limits_changed = true;
                        }
                    }
                    let mut mb_val = self.settings.ram_limit_mb.unwrap_or(512) as f32;
                    if ui
                        .add(
                            egui::Slider::new(&mut mb_val, 128.0..=2048.0)
                                .step_by(32.0)
                                .suffix(" MB"),
                        )
                        .changed()
                    {
                        self.settings.ram_limit_mb = Some((mb_val.round() as u32).clamp(128, 2048));
                        limits_changed = true;
                    }
                    if ui.button("Trim RAM Now").clicked() {
                        trim_now = true;
                    }
                });

                // The launcher's own caches, in the same bytes the budget trims. Tucking the
                // window into the tray flushes them, so this is where that can be confirmed.
                ui.add_space(6.0);
                let usage = self.ram_usage();
                ui.horizontal_wrapped(|ui| {
                    ui.label("Image caches:");
                    ui.label(
                        RichText::new(format!(
                            "{} / {} MB",
                            cache_size(usage.total()),
                            crate::ram_budget::TOTAL_CAP_BYTES / (1024 * 1024)
                        ))
                        .strong()
                        .color(accent),
                    );
                    let note = if crate::window_lifecycle::hidden_to_tray() {
                        "tucked into the tray, caches flushed".to_string()
                    } else {
                        format!(
                            "{} textures · {} waiting · {} video · {} avatar · {} profiles",
                            cache_size(usage.thumbnail_textures),
                            cache_size(usage.pending_images),
                            cache_size(usage.video_frames),
                            cache_size(usage.avatar_scene),
                            cache_size(usage.profile),
                        )
                    };
                    ui.label(RichText::new(note).size(12.0).color(p.muted));
                    // The process total includes eframe's own image loader, the driver and
                    // the overlay, so the two numbers together say where the RAM went.
                    if let Some(rss) = crate::telemetry::current_process_ram_mb() {
                        ui.label(
                            RichText::new(format!("· process {rss:.0} MB"))
                                .size(12.0)
                                .color(p.muted),
                        );
                    }
                });

                ui.add_space(8.0);
                ui.horizontal(|ui| {
                    ui.label("Launcher CPU limit:");
                    let cur_txt = self
                        .settings
                        .cpu_limit_pct
                        .map(|pct| format!("{pct}%"))
                        .unwrap_or_else(|| "Unlimited".to_string());
                    ui.label(RichText::new(cur_txt).strong().color(accent));
                });
                ui.horizontal_wrapped(|ui| {
                    ui.spacing_mut().item_spacing = egui::vec2(6.0, 6.0);
                    for (opt, lbl) in [
                        (None, "Unlimited"),
                        (Some(25), "25%"),
                        (Some(50), "50%"),
                        (Some(75), "75%"),
                    ] {
                        let sel = self.settings.cpu_limit_pct == opt;
                        let btn = egui::Button::new(
                            RichText::new(lbl)
                                .size(12.0)
                                .strong()
                                .color(if sel { accent_fg } else { p.text }),
                        )
                        .fill(if sel { accent } else { p.surface_bg })
                        .corner_radius(7);
                        if ui.add(btn).clicked() && !sel {
                            self.settings.cpu_limit_pct = opt;
                            limits_changed = true;
                        }
                    }
                    let mut cpu_val = self.settings.cpu_limit_pct.unwrap_or(100) as f32;
                    if ui
                        .add(
                            egui::Slider::new(&mut cpu_val, 15.0..=100.0)
                                .step_by(5.0)
                                .suffix("%"),
                        )
                        .changed()
                    {
                        let v = cpu_val.round() as u8;
                        self.settings.cpu_limit_pct = if v >= 100 { None } else { Some(v.clamp(10, 95)) };
                        limits_changed = true;
                    }
                });
                small_text(
                    ui,
                    "Caps only the launcher itself (also quick-tweakable from the bottom-left performance dock); Roblox games stay uncapped."
                        .to_string(),
                );
                if limits_changed {
                    save_settings(&self.settings);
                }
                if limits_changed || trim_now {
                    self.apply_runtime_resource_limits(trim_now);
                }

                ui.add_space(10.0);
                ui.add_space(10.0);
                let prev_multi = self.settings.multi_instance;
                ui.checkbox(
                    &mut self.settings.multi_instance,
                    "Allow multiple Roblox instances (two accounts at once)",
                );
                if self.settings.multi_instance != prev_multi {
                    save_settings(&self.settings);
                    self.status = if self.settings.multi_instance {
                        "Multi-instance on: every Play starts a separate Roblox copy.".to_string()
                    } else {
                        "Multi-instance off: Play reuses the running Roblox app.".to_string()
                    };
                }
                small_text(
                    ui,
                    "macOS: launches Roblox with `open -n` so a second account gets its own copy. While this is on, the launcher never auto-closes Roblox processes, so one instance cannot kill the other."
                        .to_string(),
                );

                ui.add_space(10.0);
                let prev_auto_close = self.settings.auto_close_roblox;
                ui.checkbox(
                    &mut self.settings.auto_close_roblox,
                    "Auto-close Roblox app after leaving a game (also closes Roblox tray)",
                );
                if self.settings.auto_close_roblox != prev_auto_close {
                    save_settings(&self.settings);
                    self.auto_close_flag
                        .store(self.settings.auto_close_roblox, Ordering::Relaxed);
                    if self.settings.auto_close_roblox {
                        close_tray_roblox_processes();
                        self.status = "Auto-close Roblox app enabled.".to_string();
                    } else {
                        self.status = "Auto-close Roblox app disabled.".to_string();
                    }
                }
                small_text(
                    ui,
                    "Closes the Roblox desktop/tray app after leaving a game. Active only while the launcher is running - closing it stops it completely so the official Roblox app runs normally."
                        .to_string(),
                );

                ui.add_space(10.0);
                if let Some(path) = &self.player_path.clone() {
                    if cfg!(target_os = "macos") {
                        // Report the bundle that was actually found (it may live in
                        // ~/Applications or a versioned folder), not the default path.
                        let shown = path
                            .parent()
                            .and_then(|p| p.parent())
                            .and_then(|p| p.parent())
                            .filter(|p| p.extension().is_some_and(|e| e == "app"))
                            .map(|p| p.display().to_string())
                            .unwrap_or_else(|| path.display().to_string());
                        ui.label(format!("Detected Roblox install: {shown}"));
                    } else {
                        let ver = path
                            .parent()
                            .and_then(|d| d.file_name())
                            .and_then(|n| n.to_str())
                            .unwrap_or("Unknown");
                        ui.label(format!("Detected Roblox version: {ver}"));
                    }
                    small_text(ui, path.display().to_string());
                    ui.add_space(6.0);
                    ui.horizontal(|ui| {
                        if ui.button("Open Roblox folder").clicked() {
                            if let Some(dir) = path.parent() {
                                let _ = open::that(dir);
                            }
                        }
                        if ui.button("Re-scan").clicked() {
                            self.player_path = find_player();
                            self.status = "Checked Roblox installation".to_string();
                        }
                        if ui.button("Check Update").clicked() {
                            self.check_updates(true);
                        }
                    });
                } else {
                    ui.colored_label(
                        ORANGE,
                        format!(
                            "{} was not found. Install Roblox once from roblox.com first.",
                            crate::platform::player_label()
                        ),
                    );
                    ui.add_space(4.0);
                    if ui.button("Re-scan").clicked() {
                        self.player_path = find_player();
                    }
                }
            });

            }

            ui.add_space(12.0);

            // Discord Rich Presence card
            if section == 6 {
                self.settings_discord_card(ui);
            }

            ui.add_space(12.0);

            // System Tray & Startup card
            if section == 5 {
                self.settings_tray_startup_card(ui);
            }

            ui.add_space(12.0);

            // Animations & performance card
            if section == 2 {
                self.settings_animations_card(ui);
            }

            ui.add_space(12.0);

            // In-game overlay & launch behaviour card
            if section == 3 {
                self.settings_game_overlay_card(ui);
            }

            ui.add_space(12.0);

            // Built-in FastFlags card
            if section == 4 {
                self.settings_fastflags_card(ui);
            }

            ui.add_space(12.0);

            // Advanced collapsible section (Roblox Links + Data & Cache)
            if section == 7 {
                self.settings_advanced_card(ui);
            }

            ui.add_space(12.0);

            // Logs: everything the app writes, readable and copyable in place.
            if section == 8 {
                self.settings_logs_card(ui);
            }
        });
        if self.settings_section as usize != section {
            self.settings_section = section as u8;
        }
        ui.add_space(20.0);
    }

    fn settings_discord_card(&mut self, ui: &mut egui::Ui) {
        let p = pal(ui);
        let rpc_status = self.discord_rpc.status();
        let mut changed = false;

        card_frame(ui, 18).show(ui, |ui| {
            ui.set_width(ui.available_width());
            ui.horizontal(|ui| {
                ui.label(RichText::new("Discord Rich Presence").size(17.0).strong());
                ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
                    let (badge_txt, badge_col) = if !self.settings.discord_rpc_enabled {
                        ("Disabled", p.muted)
                    } else if rpc_status.connected {
                        ("Connected", GREEN)
                    } else {
                        ("Waiting for Discord", ORANGE)
                    };
                    egui::Frame::new()
                        .fill(p.surface_bg)
                        .stroke(egui::Stroke::new(1.0, badge_col.gamma_multiply(0.55)))
                        .corner_radius(6)
                        .inner_margin(egui::Margin::symmetric(8, 3))
                        .show(ui, |ui| {
                            ui.label(RichText::new(badge_txt).size(11.5).strong().color(badge_col));
                        });
                });
            });
            ui.add_space(8.0);

            if ui
                .checkbox(
                    &mut self.settings.discord_rpc_enabled,
                    "Show active Roblox game and launcher status on Discord",
                )
                .changed()
            {
                changed = true;
            }

            if self.settings.discord_rpc_enabled {
                ui.add_space(6.0);
                if ui
                    .checkbox(
                        &mut self.settings.discord_rpc_show_idle,
                        "Show \"Browsing\" while in the launcher",
                    )
                    .changed()
                {
                    changed = true;
                }

                ui.add_space(8.0);
                ui.horizontal(|ui| {
                    ui.label("Application ID (optional):");
                    let edit = egui::TextEdit::singleline(&mut self.settings.discord_rpc_app_id)
                        .hint_text(format!(
                            "Default ({})",
                            crate::discord_rpc::DEFAULT_DISCORD_APP_ID
                        ))
                        .desired_width(210.0);
                    if ui.add(edit).lost_focus() {
                        let trimmed = self.settings.discord_rpc_app_id.trim().to_string();
                        if self.settings.discord_rpc_app_id != trimmed {
                            self.settings.discord_rpc_app_id = trimmed;
                        }
                        changed = true;
                    }
                    if !self.settings.discord_rpc_app_id.trim().is_empty()
                        && ui.button("Use Default").clicked()
                    {
                        self.settings.discord_rpc_app_id.clear();
                        changed = true;
                    }
                });
                ui.add_space(4.0);
                small_text(
                    ui,
                    "Shows the active game name, creator, icon, elapsed timer, and \"Open on Roblox\" button. Leave Application ID blank for default Roblox RPC, or use your own ID from discord.com/developers/applications."
                        .to_string(),
                );
                if !rpc_status.status_text.is_empty() {
                    ui.add_space(4.0);
                    small_text(ui, format!("Status: {}", rpc_status.status_text));
                }
            } else {
                ui.add_space(4.0);
                small_text(
                    ui,
                    "Discord Rich Presence is off. Enable it to broadcast what Roblox game you're playing."
                        .to_string(),
                );
            }
        });

        if changed {
            save_settings(&self.settings);
            self.sync_discord_presence();
            self.sync_tray_state();
        }
    }

    fn settings_tray_startup_card(&mut self, ui: &mut egui::Ui) {
        let p = pal(ui);
        let mut save_needed = false;

        card_frame(ui, 18).show(ui, |ui| {
            ui.set_width(ui.available_width());
            ui.horizontal(|ui| {
                ui.label(
                    RichText::new(crate::platform::tray_card_title())
                        .size(17.0)
                        .strong(),
                );
                ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
                    let (badge_txt, badge_col) =
                        match (self.settings.tray_enabled, self.settings.start_with_windows) {
                            (true, true) => ("Tray & Startup On", GREEN),
                            (true, false) => ("Tray Active", GREEN),
                            (false, true) => ("Startup On", ORANGE),
                            (false, false) => ("Standard Window", p.muted),
                        };
                    egui::Frame::new()
                        .fill(p.surface_bg)
                        .stroke(egui::Stroke::new(1.0, badge_col.gamma_multiply(0.55)))
                        .corner_radius(6)
                        .inner_margin(egui::Margin::symmetric(8, 3))
                        .show(ui, |ui| {
                            ui.label(
                                RichText::new(badge_txt)
                                    .size(11.5)
                                    .strong()
                                    .color(badge_col),
                            );
                        });
                });
            });
            ui.add_space(8.0);

            let prev_tray = self.settings.tray_enabled;
            if ui
                .checkbox(
                    &mut self.settings.tray_enabled,
                    format!(
                        "Keep the launcher icon in the {} ({})",
                        crate::platform::tray_label(),
                        crate::platform::os_name()
                    ),
                )
                .changed()
            {
                save_needed = true;
                self.status = if self.settings.tray_enabled {
                    format!("{} mode enabled.", crate::platform::tray_label_titlecase())
                } else {
                    format!("{} mode disabled.", crate::platform::tray_label_titlecase())
                };
            }

            ui.indent("tray_sub_options", |ui| {
                ui.add_enabled_ui(self.settings.tray_enabled, |ui| {
                    // macOS: the red button quits CREBLOX like any other app, so there is no
                    // "minimize on close" to offer there (`window_lifecycle`).
                    if !cfg!(target_os = "macos")
                        && ui
                            .checkbox(
                                &mut self.settings.tray_minimize_on_close,
                                format!(
                                    "Minimize to the {} when clicking Close (X)",
                                    crate::platform::tray_label()
                                ),
                            )
                            .changed()
                    {
                        save_needed = true;
                    }
                    ui.add_space(4.0);
                    ui.horizontal(|ui| {
                        if ui.button("Minimize now").clicked() {
                            let show_tip = !self.tray_minimize_balloon_shown;
                            self.tray_minimize_balloon_shown = true;
                            self.hide_to_tray(&ui.ctx().clone(), show_tip);
                        }
                        if ui
                            .button(RichText::new("Quit Launcher").color(RED))
                            .clicked()
                        {
                            self.quit_app();
                        }
                    });
                });
            });
            if prev_tray != self.settings.tray_enabled {
                self.sync_tray_state();
            }

            ui.add_space(10.0);

            // One switch for every periodic background refresh. Off means the lists and counts
            // only move when the user loads a page, changes a tab or filter, or asks for a
            // refresh: no timer re-fetches anything.
            let mut auto_refresh = self.settings.auto_refresh;
            if ui
                .checkbox(&mut auto_refresh, "Automatic background refresh")
                .changed()
            {
                self.settings.auto_refresh = auto_refresh;
                save_needed = true;
                self.status = if auto_refresh {
                    "Automatic background refresh on.".to_string()
                } else {
                    "Automatic background refresh off: lists only change when you ask."
                        .to_string()
                };
            }
            ui.label(
                RichText::new(
                    "Silently update game lists, player counts, and friends activity in the background",
                )
                .size(12.0)
                .color(p.muted),
            );
            ui.add_space(10.0);

            let mut startup_enabled = self.settings.start_with_windows;
            if ui
                .checkbox(
                    &mut startup_enabled,
                    format!(
                        "Start the launcher automatically with {}",
                        crate::platform::os_name()
                    ),
                )
                .changed()
            {
                match set_startup(startup_enabled, self.settings.start_minimized_to_tray) {
                    Ok(()) => {
                        self.settings.start_with_windows = startup_enabled;
                        self.startup_err = None;
                        save_needed = true;
                        self.status = if startup_enabled {
                            "Enabled start at login.".to_string()
                        } else {
                            "Disabled start at login.".to_string()
                        };
                    }
                    Err(e) => {
                        self.startup_err = Some(e);
                    }
                }
            }

            ui.indent("startup_sub_options", |ui| {
                ui.add_enabled_ui(self.settings.start_with_windows, |ui| {
                    if ui
                        .checkbox(
                            &mut self.settings.start_minimized_to_tray,
                            format!(
                                "Start minimized to the {} on boot (--tray)",
                                crate::platform::tray_label()
                            ),
                        )
                        .changed()
                    {
                        match set_startup(true, self.settings.start_minimized_to_tray) {
                            Ok(()) => {
                                self.startup_err = None;
                                save_needed = true;
                            }
                            Err(e) => {
                                self.startup_err = Some(e);
                            }
                        }
                    }
                });
            });

            ui.add_space(4.0);
            small_text(ui, crate::platform::tray_help_text().to_string());
            if let Some(err) = &self.startup_err {
                ui.add_space(4.0);
                ui.label(RichText::new(err).size(12.0).color(RED));
            }
        });

        if save_needed {
            save_settings(&self.settings);
            self.sync_tray_state();
        }
    }

    fn settings_animations_card(&mut self, ui: &mut egui::Ui) {
        let mut changed = false;
        card_frame(ui, 18).show(ui, |ui| {
            ui.set_width(ui.available_width());
            ui.label(
                RichText::new("Animations & Performance")
                    .size(17.0)
                    .strong(),
            );
            ui.add_space(6.0);
            let master = self.settings.animations_enabled;
            changed |= ui
                .checkbox(&mut self.settings.animations_enabled, "All animations")
                .on_hover_text(
                    "Master switch: off means no fades, no slides and no moving UI at all.",
                )
                .changed();
            ui.add_enabled_ui(master, |ui| {
                ui.indent("anim_details", |ui| {
                    changed |= ui
                        .checkbox(
                            &mut self.settings.hover_animations,
                            "Hover fades, rings and the sliding nav bar",
                        )
                        .changed();
                    changed |= ui
                        .checkbox(
                            &mut self.settings.animated_backgrounds,
                            "Animated backgrounds (login backdrop, appearance previews)",
                        )
                        .changed();
                    changed |= ui
                        .checkbox(
                            &mut self.settings.video_previews,
                            "Game preview videos on hover (uses extra RAM, CPU and data)",
                        )
                        .changed();
                });
            });
            ui.add_space(4.0);
            if master && ui.button("Turn every animation off").clicked() {
                self.settings.animations_enabled = false;
                self.settings.hover_animations = false;
                self.settings.animated_backgrounds = false;
                changed = true;
            }
            small_text(
                ui,
                "Turning these off makes the launcher lighter and calmer; nothing else changes."
                    .to_string(),
            );
        });
        if changed {
            save_settings(&self.settings);
            apply_theme(ui.ctx(), &self.settings);
        }
    }

    fn settings_game_overlay_card(&mut self, ui: &mut egui::Ui) {
        let mut changed = false;
        card_frame(ui, 18).show(ui, |ui| {
            ui.set_width(ui.available_width());
            ui.label(RichText::new("In-Game Overlay & Launch Behavior").size(17.0).strong());
            ui.add_space(6.0);

            changed |= ui
                .checkbox(
                    &mut self.settings.overlay_enabled,
                    "Show server region popup on top of the Roblox game",
                )
                .changed();
            ui.add_enabled_ui(self.settings.overlay_enabled, |ui| {
                ui.indent("overlay_options", |ui| {
                    ui.horizontal(|ui| {
                        ui.label("Position:");
                        let labels = ["Top left", "Top right", "Bottom left", "Bottom right"];
                        let cur = self.settings.overlay_corner.min(3) as usize;
                        egui::ComboBox::from_id_salt("overlay_corner")
                            .selected_text(labels[cur])
                            .show_ui(ui, |ui| {
                                for (i, label) in labels.iter().enumerate() {
                                    if ui
                                        .selectable_label(cur == i, *label)
                                        .clicked()
                                    {
                                        self.settings.overlay_corner = i as u8;
                                        changed = true;
                                    }
                                }
                            });
                    });
                    ui.horizontal(|ui| {
                        ui.label("Visible for:");
                        let mut secs = self.settings.overlay_duration_secs as i32;
                        let resp = ui.add(
                            egui::Slider::new(&mut secs, 0..=60)
                                .suffix(" s")
                                .custom_formatter(|v, _| {
                                    if v < 0.5 { "until game closes".to_string() } else { format!("{v:.0} s") }
                                }),
                        );
                        if resp.changed() {
                            self.settings.overlay_duration_secs = secs.clamp(0, 255) as u8;
                            changed = true;
                        }
                    });
                    ui.horizontal(|ui| {
                        ui.label("Opacity:");
                        changed |= ui
                            .add(egui::Slider::new(&mut self.settings.overlay_opacity, 0.2..=1.0))
                            .changed();
                    });
                    changed |= ui
                        .checkbox(&mut self.settings.overlay_show_ip, "Show server IP address")
                        .changed();
                    changed |= ui
                        .checkbox(&mut self.settings.overlay_show_job_id, "Show server Job ID")
                        .changed();
                });
            });
            small_text(
                ui,
                "Overlays are drawn above the game window (including fullscreen), only while Roblox is in front, and cannot be clicked. Changes apply live, even in the middle of a game."
                    .to_string(),
            );

            ui.add_space(10.0);
            ui.separator();
            ui.add_space(8.0);

            let corner_labels = ["Top left", "Top right", "Bottom left", "Bottom right"];

            changed |= ui
                .checkbox(
                    &mut self.settings.party_overlay,
                    "Party overlay (member tiles with in-server / loading / disconnected outlines)",
                )
                .changed();
            ui.add_enabled_ui(self.settings.party_overlay, |ui| {
                ui.indent("party_overlay_options", |ui| {
                    ui.horizontal(|ui| {
                        ui.label("Position:");
                        let cur = self.settings.party_overlay_corner.min(3) as usize;
                        egui::ComboBox::from_id_salt("party_overlay_corner")
                            .selected_text(corner_labels[cur])
                            .show_ui(ui, |ui| {
                                for (i, label) in corner_labels.iter().enumerate() {
                                    if ui.selectable_label(cur == i, *label).clicked() {
                                        self.settings.party_overlay_corner = i as u8;
                                        changed = true;
                                    }
                                }
                            });
                    });
                });
            });
            small_text(
                ui,
                "Green means the member is in this exact server, grey that they are still loading in, red that their connection dropped."
                    .to_string(),
            );

            changed |= ui
                .checkbox(
                    &mut self.settings.overlay_stats_enabled,
                    "Live stats overlay (CPU, RAM, ping, session timer, clock)",
                )
                .changed();
            ui.add_enabled_ui(self.settings.overlay_stats_enabled, |ui| {
                ui.indent("overlay_stats_options", |ui| {
                    ui.horizontal(|ui| {
                        ui.label("Position:");
                        let cur = self.settings.overlay_stats_corner.min(3) as usize;
                        egui::ComboBox::from_id_salt("overlay_stats_corner")
                            .selected_text(corner_labels[cur])
                            .show_ui(ui, |ui| {
                                for (i, label) in corner_labels.iter().enumerate() {
                                    if ui.selectable_label(cur == i, *label).clicked() {
                                        self.settings.overlay_stats_corner = i as u8;
                                        changed = true;
                                    }
                                }
                            });
                    });
                    ui.horizontal_wrapped(|ui| {
                        changed |= ui.checkbox(&mut self.settings.overlay_stats_cpu, "CPU").changed();
                        changed |= ui.checkbox(&mut self.settings.overlay_stats_ram, "RAM").changed();
                        changed |= ui.checkbox(&mut self.settings.overlay_stats_ping, "Ping").changed();
                        changed |= ui
                            .checkbox(&mut self.settings.overlay_stats_fps_cap, "FPS cap")
                            .changed();
                        // Roblox's own counter is the only accurate FPS reading available from
                        // outside the game, so the toggle enables it instead of guessing.
                        let mut show_fps = self.fastflags.show_fps;
                        if ui
                            .checkbox(&mut show_fps, "FPS counter (Roblox's own)")
                            .changed()
                        {
                            self.fastflags.show_fps = show_fps;
                            let _ = save_fastflags(&self.fastflags);
                            let _ = sync_client_fastflags(
                                &self.fastflags,
                                self.settings.target_fps,
                                &[],
                            );
                            self.status = if show_fps {
                                "Roblox's FPS counter will appear on the next game launch".to_string()
                            } else {
                                "Roblox's FPS counter turned off".to_string()
                            };
                        }
                        changed |= ui
                            .checkbox(&mut self.settings.overlay_stats_session, "Session timer")
                            .changed();
                        changed |= ui
                            .checkbox(&mut self.settings.overlay_stats_clock, "Clock")
                            .changed();
                    });
                    small_text(
                        ui,
                        "CPU / RAM are Roblox's own usage. Ping is a live TCP round trip to the game server (it falls back to Roblox's web edge). The FPS counter is Roblox's own accurate counter, drawn by the game itself."
                            .to_string(),
                    );
                });
            });

            ui.add_space(8.0);
            changed |= ui
                .checkbox(
                    &mut self.settings.overlay_flags_enabled,
                    "FastFlags overlay (shows the FastFlags that are active)",
                )
                .changed();
            ui.add_enabled_ui(self.settings.overlay_flags_enabled, |ui| {
                ui.indent("overlay_flags_options", |ui| {
                    ui.horizontal(|ui| {
                        ui.label("Position:");
                        let cur = self.settings.overlay_flags_corner.min(3) as usize;
                        egui::ComboBox::from_id_salt("overlay_flags_corner")
                            .selected_text(corner_labels[cur])
                            .show_ui(ui, |ui| {
                                for (i, label) in corner_labels.iter().enumerate() {
                                    if ui.selectable_label(cur == i, *label).clicked() {
                                        self.settings.overlay_flags_corner = i as u8;
                                        changed = true;
                                    }
                                }
                            });
                    });
                    ui.horizontal(|ui| {
                        ui.label("Max lines:");
                        let mut lines = self.settings.overlay_flags_max_lines as i32;
                        if ui.add(egui::Slider::new(&mut lines, 1..=40)).changed() {
                            self.settings.overlay_flags_max_lines = lines.clamp(1, 40) as u8;
                            changed = true;
                        }
                    });
                });
            });

            ui.add_space(8.0);
            changed |= ui
                .checkbox(
                    &mut self.settings.overlay_game_enabled,
                    "Game info overlay (game name, players online, place ID)",
                )
                .changed();
            ui.add_enabled_ui(self.settings.overlay_game_enabled, |ui| {
                ui.indent("overlay_game_options", |ui| {
                    ui.horizontal(|ui| {
                        ui.label("Position:");
                        let cur = self.settings.overlay_game_corner.min(3) as usize;
                        egui::ComboBox::from_id_salt("overlay_game_corner")
                            .selected_text(corner_labels[cur])
                            .show_ui(ui, |ui| {
                                for (i, label) in corner_labels.iter().enumerate() {
                                    if ui.selectable_label(cur == i, *label).clicked() {
                                        self.settings.overlay_game_corner = i as u8;
                                        changed = true;
                                    }
                                }
                            });
                    });
                });
            });

            ui.add_space(8.0);
            changed |= ui
                .checkbox(
                    &mut self.settings.crosshair_enabled,
                    "Crosshair overlay (drawn in the middle of the game)",
                )
                .changed();
            ui.add_enabled_ui(self.settings.crosshair_enabled, |ui| {
                ui.indent("crosshair_options", |ui| {
                    ui.horizontal_wrapped(|ui| {
                        ui.label("Style:");
                        let styles = ["Dot", "Cross", "Circle", "Cross + dot"];
                        let cur = self.settings.crosshair_style.min(3) as usize;
                        egui::ComboBox::from_id_salt("crosshair_style")
                            .selected_text(styles[cur])
                            .show_ui(ui, |ui| {
                                for (i, label) in styles.iter().enumerate() {
                                    if ui.selectable_label(cur == i, *label).clicked() {
                                        self.settings.crosshair_style = i as u8;
                                        changed = true;
                                    }
                                }
                            });
                        ui.add_space(8.0);
                        ui.label("Color:");
                        changed |= ui
                            .color_edit_button_srgb(&mut self.settings.crosshair_color)
                            .changed();
                    });
                    changed |= ui
                        .add(egui::Slider::new(&mut self.settings.crosshair_size, 4..=120).text("Size"))
                        .changed();
                    changed |= ui
                        .add(
                            egui::Slider::new(&mut self.settings.crosshair_thickness, 1..=10)
                                .text("Thickness"),
                        )
                        .changed();
                    changed |= ui
                        .add(egui::Slider::new(&mut self.settings.crosshair_gap, 0..=60).text("Center gap"))
                        .changed();
                    changed |= ui
                        .add(
                            egui::Slider::new(&mut self.settings.crosshair_opacity, 0.1..=1.0)
                                .text("Opacity"),
                        )
                        .changed();
                    changed |= ui
                        .add(
                            egui::Slider::new(&mut self.settings.crosshair_offset_x, -100..=100)
                                .text("Offset X"),
                        )
                        .changed();
                    changed |= ui
                        .add(
                            egui::Slider::new(&mut self.settings.crosshair_offset_y, -100..=100)
                                .text("Offset Y"),
                        )
                        .changed();
                    small_text(
                        ui,
                        "Use Offset X / Y to line the crosshair up exactly with the middle of your game view."
                            .to_string(),
                    );
                });
            });

            ui.add_space(10.0);
            ui.separator();
            ui.add_space(8.0);

            // One entry point for the on-screen editor: it starts from the positions the HUD
            // is using right now, and the custom image can be moved and resized there too.
            ui.horizontal(|ui| {
                if ui.button("Edit HUD positions…").clicked() {
                    self.start_overlay_edit();
                }
                small_text(
                    ui,
                    "Drag every card, the crosshair and the picture itself (corner handles resize)."
                        .to_string(),
                );
            });
            ui.add_space(10.0);
            ui.separator();
            ui.add_space(8.0);

            // Custom image overlay: any picture on top of the game, in a corner of choice.
            changed |= ui
                .checkbox(
                    &mut self.settings.overlay_image_enabled,
                    "Custom image overlay (PNG / JPG / WEBP drawn on top of the game)",
                )
                .changed();
            ui.add_enabled_ui(self.settings.overlay_image_enabled, |ui| {
                ui.indent("overlay_image_options", |ui| {
                    ui.horizontal(|ui| {
                        let mut path = self.settings.overlay_image_path.clone();
                        if ui
                            .add(
                                egui::TextEdit::singleline(&mut path)
                                    .hint_text("Path to an image file")
                                    .desired_width(320.0),
                            )
                            .changed()
                        {
                            self.settings.overlay_image_path = path;
                            changed = true;
                        }
                        if ui.button("Choose image…").clicked() {
                            if let Some(picked) = choose_image_file() {
                                self.settings.overlay_image_path = picked;
                                changed = true;
                            }
                        }
                        if ui.button("Clear").clicked() {
                            self.settings.overlay_image_path.clear();
                            changed = true;
                        }
                    });
                    if !self.settings.overlay_image_path.is_empty()
                        && !std::path::Path::new(&self.settings.overlay_image_path).is_file()
                    {
                        ui.colored_label(RED, "That file does not exist (or cannot be read).");
                    }
                    ui.horizontal(|ui| {
                        ui.label("Position:");
                        let cur = self.settings.overlay_image_corner.min(3) as usize;
                        egui::ComboBox::from_id_salt("overlay_image_corner")
                            .selected_text(corner_labels[cur])
                            .show_ui(ui, |ui| {
                                for (i, label) in corner_labels.iter().enumerate() {
                                    if ui.selectable_label(cur == i, *label).clicked() {
                                        self.settings.overlay_image_corner = i as u8;
                                        changed = true;
                                    }
                                }
                            });
                    });
                    changed |= ui
                        .add(
                            egui::Slider::new(&mut self.settings.overlay_image_size, 5..=100)
                                .suffix(" % height")
                                .text("Size"),
                        )
                        .changed();
                    changed |= ui
                        .add(
                            egui::Slider::new(&mut self.settings.overlay_image_opacity, 0.1..=1.0)
                                .text("Opacity"),
                        )
                        .changed();
                    changed |= ui
                        .add(
                            egui::Slider::new(&mut self.settings.overlay_image_offset_x, -2000..=2000)
                                .text("Offset X"),
                        )
                        .changed();
                    changed |= ui
                        .add(
                            egui::Slider::new(&mut self.settings.overlay_image_offset_y, -2000..=2000)
                                .text("Offset Y"),
                        )
                        .changed();
                    small_text(
                        ui,
                        if (crate::overlay_spec::SavedImageBox {
                            x: self.settings.overlay_image_x,
                            y: self.settings.overlay_image_y,
                            w: self.settings.overlay_image_w,
                            h: self.settings.overlay_image_h,
                        })
                        .is_saved()
                        {
                            format!(
                                "Saved from the HUD editor: {} x {} at {}, {}. Use Edit HUD positions… to move it again, or Reset there to go back to the corner.",
                                self.settings.overlay_image_w,
                                self.settings.overlay_image_h,
                                self.settings.overlay_image_x,
                                self.settings.overlay_image_y
                            )
                        } else {
                            "The picture keeps its aspect ratio and is scaled by height. Use the offsets to fine-tune the corner placement, or drag it in Edit HUD positions…."
                                .to_string()
                        },
                    );
                });
            });

            ui.add_space(10.0);
            ui.separator();
            ui.add_space(8.0);

            changed |= ui
                .checkbox(
                    &mut self.settings.show_server_badge,
                    "Show the \"Connected server\" badge in the launcher",
                )
                .changed();
            // A window the user hid themselves still comes back when the game ends.
            changed |= ui
                .checkbox(
                    &mut self.settings.return_to_launcher_on_leave,
                    "Return to the launcher when I leave a game",
                )
                .changed();
            // On macOS the game tuck is not optional, so neither of these exists there:
            // starting a game always moves CREBLOX into the menu bar.
            #[cfg(not(target_os = "macos"))]
            {
                changed |= ui
                    .checkbox(
                        &mut self.settings.minimize_on_game_launch,
                        "Minimize the launcher while a game is launching",
                    )
                    .changed();
                changed |= ui
                    .checkbox(
                        &mut self.settings.close_launcher_during_game,
                        "Close the launcher window while I play (it stays in the menu bar)",
                    )
                    .changed();
                small_text(
                    ui,
                    "The launcher keeps running in the tray while you play: the tray icon, the in-game overlays and the settings stay available, and the window comes back by itself when you leave the game."
                        .to_string(),
                );
            }
            #[cfg(target_os = "macos")]
            small_text(
                ui,
                "Starting a game moves CREBLOX into the menu bar: the menu-bar icon, the in-game overlays and your settings stay available, and Open CREBLOX brings the window back. Finishing a game leaves it there. The red close button quits CREBLOX like any other Mac app."
                    .to_string(),
            );
        });
        if changed {
            save_settings(&self.settings);
        }
    }

    fn settings_fastflags_card(&mut self, ui: &mut egui::Ui) {
        let p = pal(ui);

        card_frame(ui, 18).show(ui, |ui| {
            ui.set_width(ui.available_width());
            let mut changed = false;
            let mut removed_keys: Vec<String> = Vec::new();

            ui.horizontal(|ui| {
                ui.label(RichText::new("FastFlags").size(17.0).strong());
                ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
                    if ui.button("Reset").clicked() {
                        for k in self.fastflags.custom_flags.keys() {
                            removed_keys.push(k.clone());
                        }
                        self.fastflags.reset_all();
                        changed = true;
                    }
                    if ui.button("Quality").clicked() {
                        self.fastflags.apply_quality_preset();
                        changed = true;
                    }
                    if ui.button("Max FPS").clicked() {
                        self.fastflags.apply_competitive_preset();
                        changed = true;
                    }
                });
            });
            ui.add_space(8.0);

            ui.horizontal_wrapped(|ui| {
                ui.label("Renderer:");
                let prev_ren = self.fastflags.renderer;
                egui::ComboBox::from_id_salt("ff_renderer")
                    .selected_text(self.fastflags.renderer.label())
                    .show_ui(ui, |ui| {
                        for mode in RendererMode::ALL {
                            ui.selectable_value(&mut self.fastflags.renderer, mode, mode.label());
                        }
                    });
                if self.fastflags.renderer != prev_ren {
                    changed = true;
                }

                ui.add_space(12.0);
                ui.label("Lighting:");
                let prev_light = self.fastflags.lighting;
                egui::ComboBox::from_id_salt("ff_lighting")
                    .selected_text(self.fastflags.lighting.label())
                    .show_ui(ui, |ui| {
                        for mode in LightingMode::ALL {
                            ui.selectable_value(&mut self.fastflags.lighting, mode, mode.label());
                        }
                    });
                if self.fastflags.lighting != prev_light {
                    changed = true;
                }
            });

            ui.add_space(8.0);
            ui.horizontal_wrapped(|ui| {
                ui.label("Anti-aliasing (MSAA):");
                let prev_msaa = self.fastflags.msaa;
                egui::ComboBox::from_id_salt("ff_msaa")
                    .selected_text(match self.fastflags.msaa {
                        None => "Default".to_string(),
                        Some(n) => format!("{n}x"),
                    })
                    .show_ui(ui, |ui| {
                        ui.selectable_value(&mut self.fastflags.msaa, None, "Default");
                        for n in [1u8, 2, 4, 8] {
                            ui.selectable_value(&mut self.fastflags.msaa, Some(n), format!("{n}x"));
                        }
                    });
                if self.fastflags.msaa != prev_msaa {
                    changed = true;
                }

                ui.add_space(12.0);
                ui.label("Quality level:");
                let prev_q = self.fastflags.quality_level;
                egui::ComboBox::from_id_salt("ff_quality_level")
                    .selected_text(match self.fastflags.quality_level {
                        None => "Default (in-game slider)".to_string(),
                        Some(n) => format!("Forced {n}"),
                    })
                    .show_ui(ui, |ui| {
                        ui.selectable_value(
                            &mut self.fastflags.quality_level,
                            None,
                            "Default (in-game slider)",
                        );
                        for n in 1u8..=21 {
                            ui.selectable_value(
                                &mut self.fastflags.quality_level,
                                Some(n),
                                format!("Forced {n}"),
                            );
                        }
                    });
                if self.fastflags.quality_level != prev_q {
                    changed = true;
                }
            });
            ui.add_space(8.0);
            let prev = (
                self.fastflags.disable_shadows,
                self.fastflags.low_quality_textures,
                self.fastflags.disable_post_fx,
                self.fastflags.disable_grass,
                self.fastflags.disable_telemetry,
                self.fastflags.show_fps,
            );
            ui.checkbox(
                &mut self.fastflags.disable_shadows,
                "Disable player & world shadows",
            );
            ui.checkbox(
                &mut self.fastflags.low_quality_textures,
                "Low texture quality",
            );
            ui.checkbox(
                &mut self.fastflags.disable_post_fx,
                "Disable post-processing (bloom/blur)",
            );
            ui.checkbox(&mut self.fastflags.disable_grass, "Disable 3D grass");
            ui.checkbox(&mut self.fastflags.disable_telemetry, "Disable telemetry");
            ui.checkbox(
                &mut self.fastflags.show_fps,
                "Show Roblox's built-in FPS counter in game",
            );
            if prev
                != (
                    self.fastflags.disable_shadows,
                    self.fastflags.low_quality_textures,
                    self.fastflags.disable_post_fx,
                    self.fastflags.disable_grass,
                    self.fastflags.disable_telemetry,
                    self.fastflags.show_fps,
                )
            {
                changed = true;
            }

            ui.add_space(10.0);
            ui.separator();
            ui.add_space(8.0);

            ui.horizontal(|ui| {
                ui.label(RichText::new("Custom Flags").size(14.0).strong());
                ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
                    if ui
                        .button(if self.ff_json_open {
                            "Hide JSON"
                        } else {
                            "JSON"
                        })
                        .clicked()
                    {
                        self.ff_json_open = !self.ff_json_open;
                        if self.ff_json_open && self.ff_json_buf.trim().is_empty() {
                            self.ff_json_buf = export_effective_flags_json(
                                &self.fastflags,
                                self.settings.target_fps,
                            );
                        }
                    }
                });
            });
            ui.add_space(4.0);

            ui.horizontal(|ui| {
                ui.add(
                    egui::TextEdit::singleline(&mut self.ff_new_key)
                        .hint_text("FFlag name")
                        .desired_width(230.0),
                );
                ui.add(
                    egui::TextEdit::singleline(&mut self.ff_new_val)
                        .hint_text("Value")
                        .desired_width(120.0),
                );
                if ui.button("Add").clicked() {
                    let key = self.ff_new_key.trim().to_string();
                    if key.is_empty() {
                        self.ff_err = Some("Enter a FastFlag name.".to_string());
                    } else {
                        let val = if self.ff_new_val.trim().is_empty() {
                            serde_json::Value::Bool(true)
                        } else {
                            parse_flag_value(&self.ff_new_val)
                        };
                        self.fastflags.custom_flags.insert(key, val);
                        self.ff_new_key.clear();
                        self.ff_new_val.clear();
                        self.ff_err = None;
                        changed = true;
                    }
                }
            });

            if !self.fastflags.custom_flags.is_empty() {
                ui.add_space(6.0);
                let entries: Vec<(String, serde_json::Value)> = self
                    .fastflags
                    .custom_flags
                    .iter()
                    .map(|(k, v)| (k.clone(), v.clone()))
                    .collect();
                for (k, v) in entries {
                    ui.horizontal(|ui| {
                        ui.label(RichText::new(&k).monospace().size(12.0));
                        ui.label(RichText::new("=").color(p.muted));
                        ui.label(
                            RichText::new(format_flag_value(&v))
                                .monospace()
                                .size(12.0)
                                .color(p.muted),
                        );
                        ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
                            if ui
                                .button(RichText::new("Remove").size(11.0).color(RED))
                                .clicked()
                            {
                                self.fastflags.custom_flags.remove(&k);
                                removed_keys.push(k.clone());
                                changed = true;
                            }
                        });
                    });
                }
            }

            if self.ff_json_open {
                ui.add_space(6.0);
                ui.add(
                    egui::TextEdit::multiline(&mut self.ff_json_buf)
                        .font(egui::TextStyle::Monospace)
                        .desired_rows(6)
                        .desired_width(f32::INFINITY),
                );
                ui.add_space(4.0);
                ui.horizontal(|ui| {
                    if ui.button("Import JSON").clicked() {
                        match import_custom_flags_json(&self.ff_json_buf, &mut self.fastflags) {
                            Ok(n) => {
                                self.ff_err = None;
                                self.status = format!("Imported {n} FastFlags.");
                                changed = true;
                            }
                            Err(e) => self.ff_err = Some(e),
                        }
                    }
                    if ui.button("Load Current").clicked() {
                        self.ff_json_buf =
                            export_effective_flags_json(&self.fastflags, self.settings.target_fps);
                        self.ff_err = None;
                    }
                    if ui.button("Copy").clicked() {
                        ui.ctx().copy_text(export_effective_flags_json(
                            &self.fastflags,
                            self.settings.target_fps,
                        ));
                        self.status = "Copied FastFlags JSON.".to_string();
                    }
                });
            }

            if let Some(err) = &self.ff_err {
                ui.add_space(4.0);
                ui.colored_label(RED, err);
            }

            if changed {
                if let Err(e) = save_fastflags(&self.fastflags) {
                    self.ff_err = Some(format!("Failed saving fastflags.json: {e}"));
                } else {
                    self.player_path = find_player();
                    let removed_refs: Vec<&str> = removed_keys.iter().map(String::as_str).collect();
                    match sync_client_fastflags(
                        &self.fastflags,
                        self.settings.target_fps,
                        &removed_refs,
                    ) {
                        Ok(()) => {
                            self.ff_err = None;
                            self.status = "FastFlags updated.".to_string();
                        }
                        Err(e) => {
                            self.ff_err = Some(e);
                        }
                    }
                }
            }
        });
    }

    fn settings_theme_card(&mut self, ui: &mut egui::Ui) {
        let p = pal(ui);
        let accent = accent_color(ui);
        let accent_fg = if is_dark_color([accent.r(), accent.g(), accent.b()]) {
            Color32::WHITE
        } else {
            Color32::from_rgb(16, 19, 26)
        };
        let mut changed = false;

        card_frame(ui, 18).show(ui, |ui| {
            ui.set_width(ui.available_width());
            let def_s = Settings::default();
            let has_custom = self.settings.bg_mode != BgMode::ThemeDefault
                || self.settings.text_mode != TextColorMode::Auto
                || self.settings.glass_edition
                || self.settings.corner_roundness != def_s.corner_roundness
                || self.settings.borders_color.is_some()
                || self.settings.profile_color.is_some()
                || self.settings.friends_color.is_some()
                || self.settings.games_border_color.is_some()
                || self.settings.text_border_color.is_some();

            ui.horizontal(|ui| {
                ui.label(RichText::new("Theme").size(17.0).strong());
                ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
                    if has_custom && ui.button("Reset to Default").clicked() {
                        self.settings.bg_mode = BgMode::ThemeDefault;
                        self.settings.text_mode = TextColorMode::Auto;
                        self.settings.glass_edition = false;
                        self.settings.glass_opacity = def_s.glass_opacity;
                        self.settings.glass_highlight = def_s.glass_highlight;
                        self.settings.corner_roundness = def_s.corner_roundness;
                        self.settings.borders_color = None;
                        self.settings.profile_color = None;
                        self.settings.friends_color = None;
                        self.settings.games_border_color = None;
                        self.settings.text_border_color = None;
                        changed = true;
                    }
                });
            });
            ui.add_space(8.0);

            // 1. Simple 1-click theme chips
            ui.horizontal_wrapped(|ui| {
                ui.spacing_mut().item_spacing = egui::vec2(8.0, 6.0);
                ui.label(RichText::new("Style:").color(p.muted));
                for pack in THEME_PACKS {
                    let is_active = self.settings.bg_mode == pack.bg_mode
                        && self.settings.borders_color == pack.borders
                        && self.settings.profile_color == pack.profile
                        && self.settings.friends_color == pack.friends
                        && self.settings.games_border_color == pack.games
                        && self.settings.text_border_color == pack.text_border
                        && if pack.bg_mode == BgMode::ThemeDefault {
                            effective_dark_mode(&self.settings) == pack.dark
                        } else {
                            self.settings.bg_color == pack.bg_color
                        };

                    let dot = Color32::from_rgb(
                        pack.preview_accent[0],
                        pack.preview_accent[1],
                        pack.preview_accent[2],
                    );
                    let resp = egui::Frame::new()
                        .fill(if is_active {
                            p.selected_bg
                        } else {
                            p.surface_bg
                        })
                        .stroke(egui::Stroke::new(
                            if is_active { 1.5 } else { 1.0 },
                            if is_active { accent } else { p.border },
                        ))
                        .corner_radius(8)
                        .inner_margin(egui::Margin::symmetric(10, 5))
                        .show(ui, |ui| {
                            ui.horizontal(|ui| {
                                let (dr, _) =
                                    ui.allocate_exact_size(egui::vec2(10.0, 10.0), Sense::hover());
                                ui.painter().circle_filled(dr.center(), 4.5, dot);
                                ui.label(RichText::new(pack.name).size(12.5).strong());
                            });
                        })
                        .response
                        .interact(Sense::click())
                        .on_hover_cursor(egui::CursorIcon::PointingHand);

                    if resp.clicked() {
                        self.settings.dark = pack.dark;
                        self.settings.bg_mode = pack.bg_mode;
                        if pack.bg_mode == BgMode::SolidColor {
                            self.settings.bg_color = pack.bg_color;
                        }
                        self.settings.text_mode = pack.text_mode;
                        self.settings.borders_color = pack.borders;
                        self.settings.profile_color = pack.profile;
                        self.settings.friends_color = pack.friends;
                        self.settings.games_border_color = pack.games;
                        self.settings.text_border_color = pack.text_border;
                        changed = true;
                    }
                }

                // Toggleable Liquid Glass UI chip (works on top of any style/background)
                let glass_active = self.settings.glass_edition;
                let glass_label = if glass_active {
                    "Liquid Glass: ON"
                } else {
                    "Liquid Glass: OFF"
                };
                let glass_resp = egui::Frame::new()
                    .fill(if glass_active {
                        p.selected_bg
                    } else {
                        p.surface_bg
                    })
                    .stroke(egui::Stroke::new(
                        if glass_active { 1.5 } else { 1.0 },
                        if glass_active { accent } else { p.border },
                    ))
                    .corner_radius(8)
                    .inner_margin(egui::Margin::symmetric(10, 5))
                    .show(ui, |ui| {
                        ui.horizontal(|ui| {
                            let (dr, _) =
                                ui.allocate_exact_size(egui::vec2(10.0, 10.0), Sense::hover());
                            let ring_col = if glass_active { accent } else { p.muted };
                            ui.painter().circle_stroke(
                                dr.center(),
                                4.2,
                                egui::Stroke::new(1.5, ring_col),
                            );
                            ui.label(RichText::new(glass_label).size(12.5).strong());
                        });
                    })
                    .response
                    .interact(Sense::click())
                    .on_hover_cursor(egui::CursorIcon::PointingHand);
                if glass_resp.clicked() {
                    self.settings.glass_edition = !self.settings.glass_edition;
                    changed = true;
                }
            });

            ui.add_space(10.0);

            // 2. Simple Mode + Background switcher
            ui.horizontal_wrapped(|ui| {
                ui.spacing_mut().item_spacing = egui::vec2(8.0, 8.0);
                ui.label(RichText::new("Mode:").color(p.muted));
                let active_dark = effective_dark_mode(&self.settings);
                for (dark_opt, label) in [(false, "Light"), (true, "Dark")] {
                    let selected = active_dark == dark_opt;
                    let btn = egui::Button::new(
                        RichText::new(label).size(12.5).strong().color(if selected {
                            accent_fg
                        } else {
                            p.text
                        }),
                    )
                    .fill(if selected { accent } else { p.surface_bg })
                    .corner_radius(7);
                    if ui.add(btn).clicked() && !selected {
                        self.settings.dark = dark_opt;
                        self.settings.text_mode = TextColorMode::Auto;
                        changed = true;
                    }
                }

                ui.add_space(10.0);
                ui.label(RichText::new("Background:").color(p.muted));
                for (mode_opt, label) in [
                    (BgMode::ThemeDefault, "Default"),
                    (BgMode::SolidColor, "Solid Color"),
                    (BgMode::Wallpaper, "Wallpaper"),
                ] {
                    let selected = self.settings.bg_mode == mode_opt;
                    let btn = egui::Button::new(
                        RichText::new(label).size(12.5).strong().color(if selected {
                            accent_fg
                        } else {
                            p.text
                        }),
                    )
                    .fill(if selected { accent } else { p.surface_bg })
                    .corner_radius(7);
                    if ui.add(btn).clicked() && !selected {
                        self.settings.bg_mode = mode_opt;
                        self.settings.text_mode = TextColorMode::Auto;
                        if mode_opt == BgMode::SolidColor {
                            self.settings.dark = is_dark_color(self.settings.bg_color);
                        }
                        changed = true;
                        if mode_opt == BgMode::Wallpaper
                            && self.wallpaper_tex.is_none()
                            && !self.settings.bg_wallpaper.trim().is_empty()
                        {
                            let path = self.settings.bg_wallpaper.clone();
                            self.request_wallpaper_load(path);
                        }
                    }
                }
            });

            if self.settings.bg_mode == BgMode::SolidColor {
                ui.add_space(8.0);
                ui.horizontal(|ui| {
                    ui.label("Background color:");
                    if ui
                        .color_edit_button_srgb(&mut self.settings.bg_color)
                        .changed()
                    {
                        self.settings.dark = is_dark_color(self.settings.bg_color);
                        self.settings.text_mode = TextColorMode::Auto;
                        changed = true;
                    }
                    let [r, g, b] = self.settings.bg_color;
                    ui.label(
                        RichText::new(format!("#{r:02X}{g:02X}{b:02X}"))
                            .monospace()
                            .size(12.0)
                            .color(p.muted),
                    );
                });
            } else if self.settings.bg_mode == BgMode::Wallpaper {
                ui.add_space(8.0);
                ui.horizontal(|ui| {
                    if ui.button("Choose Image...").clicked() {
                        self.open_wallpaper_picker();
                    }
                    if !self.settings.bg_wallpaper.is_empty() && ui.button("Clear").clicked() {
                        self.settings.bg_wallpaper.clear();
                        self.settings.bg_mode = BgMode::ThemeDefault;
                        self.wallpaper_tex = None;
                        self.wallpaper_err = None;
                        changed = true;
                    }
                    ui.add_space(8.0);
                    ui.label("Dim:");
                    let mut pct = (self.settings.bg_overlay * 100.0).round();
                    if ui
                        .add(egui::Slider::new(&mut pct, 0.0..=85.0).suffix("%"))
                        .changed()
                    {
                        self.settings.bg_overlay = (pct / 100.0).clamp(0.0, 0.85);
                        changed = true;
                    }
                });
                if let Some(err) = &self.wallpaper_err {
                    ui.colored_label(RED, err);
                }
            }

            ui.add_space(10.0);
            ui.horizontal(|ui| {
                if ui
                    .checkbox(
                        &mut self.settings.glass_edition,
                        RichText::new(
                            "Glass Liquid Edition (translucent frosted UI cards & liquid sheen)",
                        )
                        .strong(),
                    )
                    .changed()
                {
                    changed = true;
                }
            });
            if self.settings.glass_edition {
                ui.add_space(6.0);
                egui::Frame::new()
                    .fill(p.surface_bg)
                    .stroke(egui::Stroke::new(1.0, p.border))
                    .corner_radius(10)
                    .inner_margin(egui::Margin::symmetric(12, 10))
                    .show(ui, |ui| {
                        ui.set_width(ui.available_width());
                        ui.horizontal_wrapped(|ui| {
                            ui.spacing_mut().item_spacing = egui::vec2(12.0, 6.0);
                            ui.horizontal(|ui| {
                                ui.label("Glass frost:");
                                let mut pct = (self.settings.glass_opacity * 100.0).round();
                                if ui
                                    .add(egui::Slider::new(&mut pct, 20.0..=92.0).suffix("%"))
                                    .changed()
                                {
                                    self.settings.glass_opacity = (pct / 100.0).clamp(0.20, 0.92);
                                    changed = true;
                                }
                            });
                            ui.horizontal(|ui| {
                                ui.label("Liquid sheen:");
                                let mut sheen_pct = (self.settings.glass_highlight * 100.0).round();
                                if ui
                                    .add(egui::Slider::new(&mut sheen_pct, 0.0..=100.0).suffix("%"))
                                    .changed()
                                {
                                    self.settings.glass_highlight =
                                        (sheen_pct / 100.0).clamp(0.0, 1.0);
                                    changed = true;
                                }
                            });
                            ui.horizontal(|ui| {
                                ui.label("Card roundness:");
                                let mut r_val = self.settings.corner_roundness as f32;
                                if ui
                                    .add(
                                        egui::Slider::new(&mut r_val, 6.0..=22.0)
                                            .step_by(1.0)
                                            .suffix(" px"),
                                    )
                                    .changed()
                                {
                                    self.settings.corner_roundness =
                                        (r_val.round() as u8).clamp(6, 22);
                                    changed = true;
                                }
                            });
                        });
                    });
            }

            ui.add_space(12.0);
            ui.separator();
            ui.add_space(8.0);

            // 3. Clean tabbed Preview (Home | Profile | Login)
            self.settings_theme_showcase(ui, p, accent);

            ui.add_space(10.0);

            // 4. Optional Borders drawer (closed by default so it stays simple!)
            if self.settings_border_colors_section(ui, p) {
                changed = true;
            }
        });

        if changed {
            save_settings(&self.settings);
            apply_theme(ui.ctx(), &self.settings);
        }
    }

    fn settings_border_colors_section(&mut self, ui: &mut egui::Ui, p: Palette) -> bool {
        let mut changed = false;
        let toggle_id = egui::Id::NULL.with("settings_borders_drawer_open");
        let mut is_open = ui
            .ctx()
            .data(|d| d.get_temp::<bool>(toggle_id))
            .unwrap_or(false);

        ui.horizontal(|ui| {
            let arrow = if is_open { "▾" } else { "▸" };
            let r = ui.add(
                egui::Label::new(
                    RichText::new(format!("{arrow} Border Colors (optional)"))
                        .size(13.0)
                        .color(p.muted),
                )
                .sense(Sense::click()),
            );
            if r.on_hover_cursor(egui::CursorIcon::PointingHand).clicked() {
                is_open = !is_open;
                ui.ctx().data_mut(|d| d.insert_temp(toggle_id, is_open));
            }
        });

        if !is_open {
            return false;
        }

        ui.add_space(6.0);
        let rows = [
            ("Borders", self.settings.borders_color, p.border, 0u8),
            ("Profile", self.settings.profile_color, p.profile_border, 1),
            ("Friends", self.settings.friends_color, p.friends_border, 2),
            ("Games", self.settings.games_border_color, p.games_border, 3),
            (
                "Text boxes",
                self.settings.text_border_color,
                p.text_border,
                4,
            ),
        ];
        for (label, cur, fallback, slot_id) in rows {
            ui.horizontal(|ui| {
                ui.add_sized([90.0, 20.0], egui::Label::new(label));
                let mut rgb = cur.unwrap_or([fallback.r(), fallback.g(), fallback.b()]);
                if ui.color_edit_button_srgb(&mut rgb).changed() {
                    match slot_id {
                        0 => self.settings.borders_color = Some(rgb),
                        1 => self.settings.profile_color = Some(rgb),
                        2 => self.settings.friends_color = Some(rgb),
                        3 => self.settings.games_border_color = Some(rgb),
                        _ => self.settings.text_border_color = Some(rgb),
                    }
                    changed = true;
                }
                if cur.is_some() && ui.small_button("Reset").clicked() {
                    match slot_id {
                        0 => self.settings.borders_color = None,
                        1 => self.settings.profile_color = None,
                        2 => self.settings.friends_color = None,
                        3 => self.settings.games_border_color = None,
                        _ => self.settings.text_border_color = None,
                    }
                    changed = true;
                }
            });
        }
        changed
    }

    fn settings_advanced_card(&mut self, ui: &mut egui::Ui) {
        let p = pal(ui);
        card_frame(ui, 18).show(ui, |ui| {
            ui.set_width(ui.available_width());

            let header = ui.horizontal(|ui| {
                let angle = if self.settings_advanced_open {
                    std::f32::consts::FRAC_PI_2
                } else {
                    0.0
                };
                let chevron =
                    egui::Image::new(egui::include_image!("../../assets/icon_arrow_right.png"))
                        .fit_to_exact_size(egui::vec2(12.0, 12.0))
                        .rotate(angle, egui::Vec2::splat(0.5))
                        .tint(p.muted);
                let arrow_resp = ui.add(chevron.sense(Sense::click()));
                let title_resp = ui.add(
                    egui::Label::new(RichText::new("Advanced").size(17.0).strong())
                        .sense(Sense::click()),
                );
                ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
                    let summary = if self.settings_advanced_open {
                        "Hide"
                    } else {
                        "Roblox Links  •  Data & Cache"
                    };
                    ui.add(
                        egui::Label::new(RichText::new(summary).size(12.0).color(p.muted))
                            .sense(Sense::click()),
                    )
                })
                .inner
                .clicked()
                    || arrow_resp.clicked()
                    || title_resp.clicked()
            });

            if header.response.hovered() && !crate::ui::widgets::fast_scrolling(ui) {
                ui.ctx().set_cursor_icon(egui::CursorIcon::PointingHand);
            }
            if header.inner {
                self.settings_advanced_open = !self.settings_advanced_open;
            }

            if self.settings_advanced_open {
                ui.add_space(10.0);
                ui.separator();
                ui.add_space(10.0);

                // Roblox Links subsection
                ui.label(RichText::new("Roblox Links").size(15.0).strong());
                ui.add_space(4.0);
                ui.label(
                    RichText::new("Make the launcher open when you click Play on roblox.com.")
                        .color(p.muted),
                );
                ui.add_space(4.0);
                ui.horizontal(|ui| {
                    ui.label(RichText::new("Active handler:").color(p.muted));
                    ui.label(RichText::new(&self.handler).strong());
                });
                ui.add_space(8.0);
                ui.horizontal(|ui| {
                    if ui.button("Use the launcher for Roblox links").clicked() {
                        self.status = register().unwrap_or_else(|e| format!("Error: {e}"));
                        self.handler = handler_status();
                    }
                    if ui.button("Restore original").clicked() {
                        self.status = restore().unwrap_or_else(|e| format!("Error: {e}"));
                        self.handler = handler_status();
                    }
                });

                ui.add_space(12.0);
                ui.separator();
                ui.add_space(10.0);

                // Data & Cache subsection
                ui.label(RichText::new("Data & Cache").size(15.0).strong());
                ui.add_space(8.0);
                ui.horizontal(|ui| {
                    if ui.button("Refresh games").clicked() {
                        self.force_refresh_games();
                    }
                    if ui.button("Clear Continue list").clicked() {
                        self.just_launched.clear();
                        self.recent_ids.clear();
                        self.recent.clear();
                        write_ids("recent.txt", &self.recent_ids);
                    }
                    if ui.button("Open data folder").clicked() {
                        let _ = open::that(data_dir());
                    }
                });
                ui.add_space(6.0);
                small_text(ui, format!("Saved in {}", data_dir().display()));
            }
        });
    }

    fn settings_theme_showcase(&self, ui: &mut egui::Ui, p: Palette, accent: Color32) {
        let tab_id = egui::Id::NULL.with("settings_preview_tab");
        let mut tab: u8 = ui.ctx().data(|d| d.get_temp(tab_id)).unwrap_or(0);

        ui.horizontal(|ui| {
            ui.label(RichText::new("Preview:").color(p.muted));
            for (idx, label) in [(0u8, "Home"), (1, "Profile"), (2, "Login")] {
                if ui.selectable_label(tab == idx, label).clicked() {
                    tab = idx;
                    ui.ctx().data_mut(|d| d.insert_temp(tab_id, tab));
                }
            }
        });
        ui.add_space(6.0);

        let card_w = ui.available_width().min(360.0);
        let preview_h = 136.0_f32;
        let dark = effective_dark_mode(&self.settings);
        let animated = self.settings.animated_backgrounds && self.settings.animations_enabled;
        let t = if animated {
            ui.input(|i| i.time as f32)
        } else {
            0.0
        };
        if tab == 2 && animated {
            ui.ctx()
                .request_repaint_after(std::time::Duration::from_millis(33));
        }

        let paint_base = |ui: &mut egui::Ui, rect: egui::Rect| {
            let painter = ui.painter();
            painter.rect_filled(rect, CornerRadius::same(10), p.bg);
            if self.settings.bg_mode == BgMode::SolidColor {
                let [r, g, b] = self.settings.bg_color;
                painter.rect_filled(rect, CornerRadius::same(10), Color32::from_rgb(r, g, b));
            } else if self.settings.bg_mode == BgMode::Wallpaper {
                let base = Palette::of(dark).bg;
                painter.rect_filled(rect, CornerRadius::same(10), base);
                if let Some((_, tex)) = &self.wallpaper_tex {
                    let mut clipped = ui.new_child(egui::UiBuilder::new().max_rect(rect));
                    clipped.set_clip_rect(rect.intersect(ui.clip_rect()));
                    egui::Image::new(tex)
                        .corner_radius(CornerRadius::same(10))
                        .paint_at(&clipped, rect);
                    let overlay_col = if dark {
                        Color32::from_black_alpha((self.settings.bg_overlay * 255.0).round() as u8)
                    } else {
                        Color32::from_white_alpha((self.settings.bg_overlay * 255.0).round() as u8)
                    };
                    clipped
                        .painter()
                        .rect_filled(rect, CornerRadius::same(10), overlay_col);
                }
            }
        };

        let draw_home = |ui: &mut egui::Ui, w: f32| {
            ui.vertical(|ui| {
                ui.set_width(w);
                let (rect, _) =
                    ui.allocate_exact_size(egui::vec2(w, preview_h), egui::Sense::hover());
                paint_base(ui, rect);
                let painter = ui.painter_at(rect);

                // Top bar
                let top_h = 20.0;
                let top_rect = egui::Rect::from_min_max(
                    rect.min,
                    egui::pos2(rect.right(), rect.top() + top_h),
                );
                painter.rect_filled(
                    top_rect,
                    CornerRadius {
                        nw: 10,
                        ne: 10,
                        sw: 0,
                        se: 0,
                    },
                    p.card_bg,
                );
                painter.line_segment(
                    [top_rect.left_bottom(), top_rect.right_bottom()],
                    egui::Stroke::new(1.0, p.border),
                );
                // Search pill (text_border)
                let search_rect = egui::Rect::from_min_size(
                    egui::pos2(rect.left() + 48.0, rect.top() + 4.5),
                    egui::vec2((w - 86.0).max(36.0), 11.0),
                );
                painter.rect_filled(search_rect, CornerRadius::same(5), p.surface_bg);
                painter.rect_stroke(
                    search_rect,
                    CornerRadius::same(5),
                    egui::Stroke::new(1.0, p.text_border),
                    egui::StrokeKind::Inside,
                );
                painter.circle_filled(
                    egui::pos2(rect.right() - 12.0, top_rect.center().y),
                    5.0,
                    accent,
                );

                // Left sidebar
                let side_w = 38.0;
                let side_rect = egui::Rect::from_min_max(
                    egui::pos2(rect.left(), top_rect.bottom()),
                    egui::pos2(rect.left() + side_w, rect.bottom()),
                );
                painter.rect_filled(
                    side_rect,
                    CornerRadius {
                        nw: 0,
                        ne: 0,
                        sw: 10,
                        se: 0,
                    },
                    p.card_bg,
                );
                painter.line_segment(
                    [side_rect.right_top(), side_rect.right_bottom()],
                    egui::Stroke::new(1.0, p.border),
                );
                for idx in 0..4 {
                    let y = side_rect.top() + 8.0 + idx as f32 * 15.0;
                    let pill = egui::Rect::from_min_size(
                        egui::pos2(side_rect.left() + 5.0, y),
                        egui::vec2(side_w - 5.0, 10.0),
                    );
                    if idx == 0 {
                        painter.rect_filled(
                            pill,
                            CornerRadius {
                                nw: 4,
                                sw: 4,
                                ne: 0,
                                se: 0,
                            },
                            accent.gamma_multiply(0.26),
                        );
                        painter.rect_filled(
                            egui::Rect::from_min_size(
                                egui::pos2(pill.right() - 2.5, pill.top()),
                                egui::vec2(2.5, pill.height()),
                            ),
                            CornerRadius::ZERO,
                            accent,
                        );
                    } else {
                        painter.rect_filled(
                            pill.shrink2(egui::vec2(2.0, 2.0)),
                            CornerRadius::same(3),
                            p.muted.gamma_multiply(0.28),
                        );
                    }
                }

                // Body: Friends row + Game cards
                let bx = side_rect.right() + 10.0;
                let by = top_rect.bottom() + 8.0;
                painter.rect_filled(
                    egui::Rect::from_min_size(egui::pos2(bx, by), egui::vec2(36.0, 5.0)),
                    CornerRadius::same(2),
                    p.text.gamma_multiply(0.85),
                );
                for f in 0..3 {
                    let fc = egui::Rect::from_min_size(
                        egui::pos2(bx + f as f32 * 30.0, by + 9.0),
                        egui::vec2(24.0, 26.0),
                    );
                    if fc.right() < rect.right() - 6.0 {
                        painter.rect_filled(fc, CornerRadius::same(5), p.friends_card_bg);
                        painter.rect_stroke(
                            fc,
                            CornerRadius::same(5),
                            egui::Stroke::new(1.1, p.friends_border),
                            egui::StrokeKind::Inside,
                        );
                        painter.circle_filled(
                            egui::pos2(fc.center().x, fc.top() + 10.0),
                            5.5,
                            p.muted.gamma_multiply(0.45),
                        );
                        painter.circle_filled(
                            egui::pos2(fc.right() - 5.0, fc.top() + 5.0),
                            2.5,
                            GREEN,
                        );
                    }
                }

                let gy = by + 43.0;
                painter.rect_filled(
                    egui::Rect::from_min_size(egui::pos2(bx, gy), egui::vec2(44.0, 5.0)),
                    CornerRadius::same(2),
                    p.text.gamma_multiply(0.85),
                );
                let gcard_w = ((rect.right() - 10.0 - bx - 8.0) / 2.0).max(40.0);
                for g in 0..2 {
                    let gc = egui::Rect::from_min_size(
                        egui::pos2(bx + g as f32 * (gcard_w + 8.0), gy + 9.0),
                        egui::vec2(gcard_w, 46.0),
                    );
                    painter.rect_filled(gc, CornerRadius::same(6), p.card_bg);
                    painter.rect_stroke(
                        gc,
                        CornerRadius::same(6),
                        egui::Stroke::new(1.1, p.games_border),
                        egui::StrokeKind::Inside,
                    );
                    let thumb =
                        egui::Rect::from_min_max(gc.min, egui::pos2(gc.right(), gc.top() + 26.0));
                    let tcol = if g == 0 { BLUE } else { accent };
                    painter.rect_filled(
                        thumb,
                        CornerRadius {
                            nw: 6,
                            ne: 6,
                            sw: 0,
                            se: 0,
                        },
                        tcol.gamma_multiply(0.55),
                    );
                    painter.rect_filled(
                        egui::Rect::from_min_size(
                            egui::pos2(gc.left() + 5.0, thumb.bottom() + 5.0),
                            egui::vec2((gcard_w - 14.0).max(16.0), 4.0),
                        ),
                        CornerRadius::same(2),
                        p.text.gamma_multiply(0.85),
                    );
                    painter.rect_filled(
                        egui::Rect::from_min_size(
                            egui::pos2(gc.left() + 5.0, thumb.bottom() + 12.0),
                            egui::vec2((gcard_w * 0.55).max(12.0), 3.0),
                        ),
                        CornerRadius::same(2),
                        p.muted.gamma_multiply(0.7),
                    );
                }

                // Outer border
                painter.rect_stroke(
                    rect,
                    CornerRadius::same(10),
                    egui::Stroke::new(1.2, p.border),
                    egui::StrokeKind::Inside,
                );
                ui.add_space(4.0);
                ui.vertical_centered(|ui| {
                    ui.label(RichText::new("Home").size(12.0).strong().color(p.muted));
                });
            });
        };

        let draw_profile = |ui: &mut egui::Ui, w: f32| {
            ui.vertical(|ui| {
                ui.set_width(w);
                let (rect, _) =
                    ui.allocate_exact_size(egui::vec2(w, preview_h), egui::Sense::hover());
                paint_base(ui, rect);
                let painter = ui.painter_at(rect);

                // Top bar
                let top_h = 20.0;
                let top_rect = egui::Rect::from_min_max(
                    rect.min,
                    egui::pos2(rect.right(), rect.top() + top_h),
                );
                painter.rect_filled(
                    top_rect,
                    CornerRadius {
                        nw: 10,
                        ne: 10,
                        sw: 0,
                        se: 0,
                    },
                    p.card_bg,
                );
                painter.line_segment(
                    [top_rect.left_bottom(), top_rect.right_bottom()],
                    egui::Stroke::new(1.0, p.border),
                );

                // Left sidebar
                let side_w = 38.0;
                let side_rect = egui::Rect::from_min_max(
                    egui::pos2(rect.left(), top_rect.bottom()),
                    egui::pos2(rect.left() + side_w, rect.bottom()),
                );
                painter.rect_filled(
                    side_rect,
                    CornerRadius {
                        nw: 0,
                        ne: 0,
                        sw: 10,
                        se: 0,
                    },
                    p.card_bg,
                );
                painter.line_segment(
                    [side_rect.right_top(), side_rect.right_bottom()],
                    egui::Stroke::new(1.0, p.border),
                );
                for idx in 0..4 {
                    let y = side_rect.top() + 8.0 + idx as f32 * 15.0;
                    let pill = egui::Rect::from_min_size(
                        egui::pos2(side_rect.left() + 5.0, y),
                        egui::vec2(side_w - 5.0, 10.0),
                    );
                    if idx == 2 {
                        painter.rect_filled(
                            pill,
                            CornerRadius {
                                nw: 4,
                                sw: 4,
                                ne: 0,
                                se: 0,
                            },
                            accent.gamma_multiply(0.26),
                        );
                        painter.rect_filled(
                            egui::Rect::from_min_size(
                                egui::pos2(pill.right() - 2.5, pill.top()),
                                egui::vec2(2.5, pill.height()),
                            ),
                            CornerRadius::ZERO,
                            accent,
                        );
                    } else {
                        painter.rect_filled(
                            pill.shrink2(egui::vec2(2.0, 2.0)),
                            CornerRadius::same(3),
                            p.muted.gamma_multiply(0.28),
                        );
                    }
                }

                // Profile Header Card (profile_card_bg + profile_border)
                let bx = side_rect.right() + 10.0;
                let bw = (rect.right() - 10.0 - bx).max(60.0);
                let prof_card = egui::Rect::from_min_size(
                    egui::pos2(bx, top_rect.bottom() + 8.0),
                    egui::vec2(bw, 44.0),
                );
                painter.rect_filled(prof_card, CornerRadius::same(7), p.profile_card_bg);
                painter.rect_stroke(
                    prof_card,
                    CornerRadius::same(7),
                    egui::Stroke::new(1.1, p.profile_border),
                    egui::StrokeKind::Inside,
                );
                // Round avatar inside profile
                let av_center = egui::pos2(prof_card.left() + 20.0, prof_card.center().y);
                painter.circle_filled(av_center, 13.0, p.surface_bg);
                painter.circle_stroke(av_center, 13.0, egui::Stroke::new(1.2, p.profile_border));
                painter.circle_filled(av_center, 5.5, p.muted.gamma_multiply(0.55));
                // Name + @handle + verified dot
                painter.rect_filled(
                    egui::Rect::from_min_size(
                        egui::pos2(prof_card.left() + 40.0, prof_card.top() + 12.0),
                        egui::vec2((bw * 0.45).max(28.0), 5.5),
                    ),
                    CornerRadius::same(2),
                    p.text.gamma_multiply(0.9),
                );
                painter.circle_filled(
                    egui::pos2(
                        prof_card.left() + 44.0 + (bw * 0.45).max(28.0),
                        prof_card.top() + 14.5,
                    ),
                    3.0,
                    BLUE,
                );
                painter.rect_filled(
                    egui::Rect::from_min_size(
                        egui::pos2(prof_card.left() + 40.0, prof_card.top() + 22.0),
                        egui::vec2((bw * 0.30).max(20.0), 3.5),
                    ),
                    CornerRadius::same(2),
                    p.muted.gamma_multiply(0.75),
                );

                // Bio / About card (text_border)
                let bio_card = egui::Rect::from_min_size(
                    egui::pos2(bx, prof_card.bottom() + 7.0),
                    egui::vec2(bw, 26.0),
                );
                painter.rect_filled(bio_card, CornerRadius::same(6), p.surface_bg);
                painter.rect_stroke(
                    bio_card,
                    CornerRadius::same(6),
                    egui::Stroke::new(1.1, p.text_border),
                    egui::StrokeKind::Inside,
                );
                painter.rect_filled(
                    egui::Rect::from_min_size(
                        egui::pos2(bio_card.left() + 7.0, bio_card.top() + 7.0),
                        egui::vec2((bw - 24.0).max(20.0), 3.5),
                    ),
                    CornerRadius::same(2),
                    p.text.gamma_multiply(0.75),
                );
                painter.rect_filled(
                    egui::Rect::from_min_size(
                        egui::pos2(bio_card.left() + 7.0, bio_card.top() + 14.0),
                        egui::vec2((bw * 0.55).max(16.0), 3.5),
                    ),
                    CornerRadius::same(2),
                    p.muted.gamma_multiply(0.65),
                );

                // Favorite / Badge chips (games_border)
                let chip_y = bio_card.bottom() + 7.0;
                let chip_w = ((bw - 8.0) / 2.0).max(26.0);
                for c in 0..2 {
                    let chip = egui::Rect::from_min_size(
                        egui::pos2(bx + c as f32 * (chip_w + 8.0), chip_y),
                        egui::vec2(chip_w, 16.0),
                    );
                    painter.rect_filled(chip, CornerRadius::same(5), p.card_bg);
                    painter.rect_stroke(
                        chip,
                        CornerRadius::same(5),
                        egui::Stroke::new(1.0, p.games_border),
                        egui::StrokeKind::Inside,
                    );
                }

                painter.rect_stroke(
                    rect,
                    CornerRadius::same(10),
                    egui::Stroke::new(1.2, p.border),
                    egui::StrokeKind::Inside,
                );
                ui.add_space(4.0);
                ui.vertical_centered(|ui| {
                    ui.label(RichText::new("Profile").size(12.0).strong().color(p.muted));
                });
            });
        };

        let draw_login = |ui: &mut egui::Ui, w: f32| {
            ui.vertical(|ui| {
                ui.set_width(w);
                let (rect, _) =
                    ui.allocate_exact_size(egui::vec2(w, preview_h), egui::Sense::hover());
                let painter = ui.painter();
                let login_bg = if dark {
                    Color32::from_rgb(17, 19, 25)
                } else {
                    Color32::from_rgb(245, 246, 250)
                };
                painter.rect_filled(rect, CornerRadius::same(10), login_bg);

                // Real live miniature sideways-scrolling Ferris & Roblox backdrop!
                draw_login_marquee(ui, rect, t, dark, 0.36);

                // Mini centered Login card
                let card_rect = egui::Rect::from_center_size(
                    rect.center(),
                    egui::vec2((w * 0.60).clamp(96.0, 146.0), 88.0),
                );
                let card_bg = if dark {
                    Color32::from_rgba_unmultiplied(21, 25, 34, 242)
                } else {
                    Color32::from_rgba_unmultiplied(255, 253, 250, 245)
                };
                let card_border = if dark {
                    Color32::from_rgba_unmultiplied(255, 255, 255, 26)
                } else {
                    Color32::from_rgba_unmultiplied(255, 130, 72, 70)
                };
                let painter = ui.painter_at(rect);
                painter.rect_filled(
                    card_rect.translate(egui::vec2(0.0, 3.0)),
                    CornerRadius::same(9),
                    Color32::from_black_alpha(if dark { 80 } else { 28 }),
                );
                painter.rect_filled(card_rect, CornerRadius::same(9), card_bg);
                painter.rect_stroke(
                    card_rect,
                    CornerRadius::same(9),
                    egui::Stroke::new(1.0, card_border),
                    egui::StrokeKind::Inside,
                );

                // Mini static logo
                let logo_rect = egui::Rect::from_center_size(
                    egui::pos2(card_rect.center().x, card_rect.top() + 14.0),
                    egui::vec2(14.0, 14.0),
                );
                egui::Image::new(egui::include_image!("../../assets/logo.png"))
                    .paint_at(ui, logo_rect);

                // Mini title + subtitle bars
                painter.rect_filled(
                    egui::Rect::from_center_size(
                        egui::pos2(card_rect.center().x, card_rect.top() + 27.0),
                        egui::vec2(46.0, 4.5),
                    ),
                    CornerRadius::same(2),
                    p.text.gamma_multiply(0.88),
                );
                painter.rect_filled(
                    egui::Rect::from_center_size(
                        egui::pos2(card_rect.center().x, card_rect.top() + 35.0),
                        egui::vec2(64.0, 3.0),
                    ),
                    CornerRadius::same(1),
                    p.muted.gamma_multiply(0.7),
                );

                // Mini white QR square hint + tactile orange button
                let qr_mini = egui::Rect::from_center_size(
                    egui::pos2(card_rect.center().x, card_rect.top() + 52.0),
                    egui::vec2(18.0, 18.0),
                );
                painter.rect_filled(qr_mini, CornerRadius::same(3), Color32::WHITE);
                painter.rect_filled(
                    qr_mini.shrink(4.0),
                    CornerRadius::same(1),
                    Color32::from_rgb(28, 32, 40),
                );

                let btn_rect = egui::Rect::from_center_size(
                    egui::pos2(card_rect.center().x, card_rect.bottom() - 14.0),
                    egui::vec2(card_rect.width() - 28.0, 14.0),
                );
                painter.rect_filled(
                    btn_rect.translate(egui::vec2(0.0, 2.0)),
                    CornerRadius::same(4),
                    Color32::from_rgb(168, 70, 28),
                );
                painter.rect_filled(
                    btn_rect,
                    CornerRadius::same(4),
                    Color32::from_rgb(255, 107, 43),
                );

                painter.rect_stroke(
                    rect,
                    CornerRadius::same(10),
                    egui::Stroke::new(1.2, p.border),
                    egui::StrokeKind::Inside,
                );
                ui.add_space(4.0);
                ui.vertical_centered(|ui| {
                    ui.label(RichText::new("Login").size(12.0).strong().color(p.muted));
                });
            });
        };

        match tab {
            0 => draw_home(ui, card_w),
            1 => draw_profile(ui, card_w),
            _ => draw_login(ui, card_w),
        }
    }

    fn settings_updates_card(&mut self, ui: &mut egui::Ui, acts: &mut Vec<Action>) {
        let p = pal(ui);
        let accent = accent_color(ui);
        let accent_fg = if is_dark_color([accent.r(), accent.g(), accent.b()]) {
            Color32::WHITE
        } else {
            Color32::from_rgb(16, 19, 26)
        };

        card_frame(ui, 18).show(ui, |ui| {
            ui.set_width(ui.available_width());
            ui.horizontal(|ui| {
                ui.label(RichText::new("Launcher Updates").size(17.0).strong());
                ui.add_space(4.0);
                egui::Frame::new()
                    .fill(p.surface_bg)
                    .stroke(egui::Stroke::new(1.0, p.border))
                    .corner_radius(6)
                    .inner_margin(egui::Margin::symmetric(7, 2))
                    .show(ui, |ui| {
                        ui.label(
                            RichText::new(format!("v{}", env!("CARGO_PKG_VERSION")))
                                .size(11.0)
                                .strong()
                                .color(p.muted),
                        );
                    });
                ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
                    if ui.button("Releases").clicked() {
                        acts.push(Action::OpenUrl(CREBLOX_RELEASES_URL.to_string()));
                    }
                    let check_label = if self.app_update_checking {
                        "Checking..."
                    } else {
                        "Check for Updates"
                    };
                    if ui
                        .add_enabled(
                            !self.app_update_checking && !self.app_update_downloading,
                            egui::Button::new(check_label),
                        )
                        .clicked()
                    {
                        self.check_app_updates(true);
                    }
                });
            });

            ui.add_space(4.0);
            small_text(
                ui,
                "Downloads the latest release from GitHub inside the app. Installing only happens when you click Install & Restart."
                    .to_string(),
            );
            ui.add_space(6.0);
            let prev_auto_check = self.settings.auto_check_updates;
            ui.checkbox(
                &mut self.settings.auto_check_updates,
                "Check for launcher updates on startup",
            );
            if self.settings.auto_check_updates != prev_auto_check {
                save_settings(&self.settings);
                self.status = if self.settings.auto_check_updates {
                    "Startup launcher update checks enabled.".to_string()
                } else {
                    "Startup launcher update checks disabled — click Check for Updates anytime."
                        .to_string()
                };
            }
            let prev_auto_download = self.settings.auto_download_updates;
            ui.checkbox(
                &mut self.settings.auto_download_updates,
                "Download updates automatically when available (install stays manual)",
            );
            if self.settings.auto_download_updates != prev_auto_download {
                save_settings(&self.settings);
                self.status = if self.settings.auto_download_updates {
                    "Automatic update downloads enabled.".to_string()
                } else {
                    "Manual update downloads — click Download when an update appears.".to_string()
                };
            }

            ui.add_space(8.0);
            if self.update_token_saved {
                ui.horizontal_wrapped(|ui| {
                    ui.label(
                        RichText::new("GitHub token saved — private repository checks are enabled.")
                            .size(12.0)
                            .color(GREEN),
                    );
                    if ui.small_button("Remove").clicked() {
                        self.clear_update_token();
                    }
                });
            } else {
                small_text(
                    ui,
                    "Private repository? Add a read-only GitHub token (Contents: Read) so the launcher can see its releases. The token is stored in the macOS Keychain, not in settings."
                        .to_string(),
                );
                ui.horizontal(|ui| {
                    ui.add(
                        egui::TextEdit::singleline(&mut self.update_token_input)
                            .password(true)
                            .hint_text("github_pat_...")
                            .desired_width(250.0),
                    );
                    if ui.button("Save Token").clicked() {
                        self.save_update_token();
                    }
                    if ui.small_button("Create Token").clicked() {
                        acts.push(Action::OpenUrl(
                            "https://github.com/settings/tokens?type=beta".to_string(),
                        ));
                    }
                });
            }

            if self.app_update_downloading {
                ui.add_space(10.0);
                ui.label(
                    RichText::new("Downloading update...")
                        .size(12.5)
                        .strong()
                        .color(p.text),
                );
                ui.add_space(4.0);
                let (done, total) = self
                    .app_update_progress
                    .as_ref()
                    .map(|(d, t)| (d.load(Ordering::Relaxed), t.load(Ordering::Relaxed)))
                    .unwrap_or((0, 0));
                let frac = if total > 0 {
                    (done as f32 / total as f32).clamp(0.0, 1.0)
                } else {
                    0.0
                };
                let bar_text = if total > 0 {
                    format!(
                        "{:.1} / {:.1} MB ({:.0}%)",
                        done as f64 / (1024.0 * 1024.0),
                        total as f64 / (1024.0 * 1024.0),
                        frac * 100.0
                    )
                } else {
                    format!("{:.1} MB downloaded...", done as f64 / (1024.0 * 1024.0))
                };
                ui.add(
                    egui::ProgressBar::new(frac)
                        .text(bar_text)
                        .animate(true)
                        .corner_radius(6),
                );
            } else if let Some(progress) = self.app_update_install.clone() {
                ui.add_space(10.0);
                let stage = progress.stage();
                ui.label(
                    RichText::new(stage.label())
                        .size(12.5)
                        .strong()
                        .color(p.text),
                );
                ui.add_space(4.0);
                ui.add(
                    egui::ProgressBar::new(0.0)
                        .animate(true)
                        .corner_radius(6)
                        .text("Updating CREBLOX"),
                );
                ui.add_space(4.0);
                let log = progress.log();
                let count = log.lock().map(|lines| lines.len()).unwrap_or(0);
                egui::CollapsingHeader::new(format!("Details ({count} lines)"))
                    .id_salt("creblox_update_details")
                    .show(ui, |ui| {
                        // Only the rows on screen are laid out: the installer's log can
                        // run to thousands of lines and every one of them used to be built
                        // on every drawn frame of this box.
                        let row_h = ui
                            .painter()
                            .layout_no_wrap(
                                "0".to_string(),
                                egui::FontId::monospace(11.0),
                                p.muted,
                            )
                            .size()
                            .y;
                        egui::ScrollArea::vertical()
                            .id_salt("creblox_update_log")
                            .max_height(170.0)
                            .stick_to_bottom(true)
                            .show_rows(ui, row_h, count, |ui, rows| {
                                if let Ok(lines) = log.lock() {
                                    for line in lines.get(rows.clone()).unwrap_or(&[]) {
                                        // `show_rows` reserves exactly one row height per
                                        // line, so a long line must not wrap: keep it on a
                                        // single row and offer the cut-off tail on hover.
                                        ui.add(
                                            egui::Label::new(
                                                RichText::new(line)
                                                    .monospace()
                                                    .size(11.0)
                                                    .color(p.muted),
                                            )
                                            .truncate(),
                                        )
                                        .on_hover_text(line.as_str());
                                    }
                                }
                            });
                    });
            } else if let Some(rel) = self.app_update_available.clone() {
                ui.add_space(10.0);
                let is_patch = rel.kind == UpdateKind::Patch && rel.zip_url.is_none();
                let can_zip = cfg!(target_os = "macos") && rel.zip_url.is_some();
                let downloaded = can_zip && self.app_update_zip.is_some();
                let already_patched =
                    self.app_patch_applied.as_deref() == Some(rel.version.as_str());
                egui::Frame::new()
                    .fill(p.surface_bg)
                    .stroke(egui::Stroke::new(1.0, GREEN.gamma_multiply(0.55)))
                    .corner_radius(10)
                    .inner_margin(egui::Margin::same(12))
                    .show(ui, |ui| {
                        ui.set_width(ui.available_width());
                        ui.horizontal(|ui| {
                            let heading = if downloaded {
                                format!("Update v{} downloaded", rel.version)
                            } else if already_patched {
                                format!("Patch v{} active (no restart needed)", rel.version)
                            } else if is_patch {
                                format!("Small patch ready: v{} (No restart)", rel.version)
                            } else {
                                format!("New version ready: v{}", rel.version)
                            };
                            ui.label(RichText::new(heading).size(13.5).strong().color(GREEN));
                            let shown_size = if rel.zip_size > 0 {
                                rel.zip_size
                            } else {
                                rel.exe_size
                            };
                            if shown_size > 0 && !already_patched {
                                let name_prefix = rel
                                    .zip_name
                                    .as_deref()
                                    .or(rel.exe_name.as_deref())
                                    .map(|n| format!("{n} · "))
                                    .unwrap_or_default();
                                ui.label(
                                    RichText::new(format!(
                                        "({name_prefix}{:.1} MB)",
                                        shown_size as f64 / (1024.0 * 1024.0)
                                    ))
                                    .size(11.5)
                                    .color(p.muted),
                                );
                            }
                            ui.with_layout(
                                egui::Layout::right_to_left(egui::Align::Center),
                                |ui| {
                                    if downloaded && !self.app_update_installing {
                                        if ui
                                            .add(
                                                egui::Button::new(
                                                    RichText::new(format!(
                                                        "Install & Restart v{}",
                                                        rel.version
                                                    ))
                                                    .size(12.0)
                                                    .strong()
                                                    .color(accent_fg),
                                                )
                                                .fill(accent)
                                                .corner_radius(7),
                                            )
                                            .on_hover_text(
                                                "Builds the update inside CREBLOX, then reopens the launcher",
                                            )
                                            .on_hover_cursor(egui::CursorIcon::PointingHand)
                                            .clicked()
                                        {
                                            self.install_app_update();
                                        }
                                    } else if can_zip {
                                        if ui
                                            .add(
                                                egui::Button::new(
                                                    RichText::new(format!(
                                                        "Download v{}",
                                                        rel.version
                                                    ))
                                                    .size(12.0)
                                                    .strong()
                                                    .color(accent_fg),
                                                )
                                                .fill(accent)
                                                .corner_radius(7),
                                            )
                                            .on_hover_text(
                                                "Downloads the update inside the launcher; installing is a separate click",
                                            )
                                            .on_hover_cursor(egui::CursorIcon::PointingHand)
                                            .clicked()
                                        {
                                            self.start_app_update_download(false);
                                        }
                                    } else if already_patched {
                                        if self.app_staged_patch.is_some()
                                            && ui.small_button("Restart Now").clicked()
                                        {
                                            self.start_app_update_download(true);
                                        }
                                    } else if is_patch {
                                        if ui
                                            .add(
                                                egui::Button::new(
                                                    RichText::new(format!(
                                                        "Apply Patch v{}",
                                                        rel.version
                                                    ))
                                                    .size(12.0)
                                                    .strong()
                                                    .color(accent_fg),
                                                )
                                                .fill(accent)
                                                .corner_radius(7),
                                            )
                                            .on_hover_text(
                                                "Applies patch in background without closing the launcher",
                                            )
                                            .on_hover_cursor(egui::CursorIcon::PointingHand)
                                            .clicked()
                                        {
                                            self.start_app_update_download(false);
                                        }
                                    } else {
                                        let btn_txt = if rel.exe_url.is_some() {
                                            format!("Update v{}", rel.version)
                                        } else {
                                            format!("Open Release v{}", rel.version)
                                        };
                                        if ui
                                            .add(
                                                egui::Button::new(
                                                    RichText::new(btn_txt)
                                                        .size(12.0)
                                                        .strong()
                                                        .color(accent_fg),
                                                )
                                                .fill(accent)
                                                .corner_radius(7),
                                            )
                                            .on_hover_text(
                                                "Closes the launcher, downloads update, and launches automatically",
                                            )
                                            .on_hover_cursor(egui::CursorIcon::PointingHand)
                                            .clicked()
                                        {
                                            self.start_app_update_download(true);
                                        }
                                    }
                                },
                            );
                        });
                        if !rel.title.is_empty() && rel.title != rel.tag_name {
                            ui.add_space(4.0);
                            ui.label(RichText::new(&rel.title).size(12.5).strong().color(p.text));
                        }
                        if !rel.notes.is_empty() {
                            ui.add_space(6.0);
                            egui::ScrollArea::vertical()
                                .id_salt("creblox_release_notes")
                                .max_height(110.0)
                                .show(ui, |ui| {
                                    ui.add(
                                        egui::Label::new(
                                            RichText::new(&rel.notes).size(12.0).color(p.text),
                                        )
                                        .wrap(),
                                    );
                                });
                        }
                    });
            } else if let Some(status) = &self.app_update_status {
                ui.add_space(6.0);
                ui.label(RichText::new(status).size(12.0).color(p.muted));
            }

            if let Some(err) = &self.app_update_error {
                ui.add_space(6.0);
                ui.horizontal_wrapped(|ui| {
                    ui.label(RichText::new(err).size(12.0).color(ORANGE));
                    if let Some(rel) = &self.app_update_available {
                        if ui.small_button("Download in Browser").clicked() {
                            acts.push(Action::OpenUrl(rel.html_url.clone()));
                        }
                    }
                });
            }
        });
    }
}

/// Opens the native file picker and returns the chosen image path.
fn choose_image_file() -> Option<String> {
    #[cfg(target_os = "macos")]
    {
        let out = std::process::Command::new("/usr/bin/osascript")
            .args([
                "-e",
                "POSIX path of (choose file with prompt \"Choose an overlay image\" of type {\"public.image\"})",
            ])
            .output()
            .ok()?;
        if !out.status.success() {
            return None;
        }
        let path = String::from_utf8_lossy(&out.stdout).trim().to_string();
        if path.is_empty() { None } else { Some(path) }
    }
    #[cfg(not(target_os = "macos"))]
    {
        None
    }
}

impl Creblox {
    /// Logs page: the app log and the overlay log, readable, copyable and clearable.
    fn settings_logs_card(&mut self, ui: &mut egui::Ui) {
        let p = pal(ui);
        card_frame(ui, 18).show(ui, |ui| {
            ui.set_width(ui.available_width());
            ui.horizontal(|ui| {
                ui.label(RichText::new("Logs").size(17.0).strong());
                ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
                    if ui.button("Copy all").clicked() {
                        let all = format!(
                            "== log.txt ==\n{}\n\n== overlay.log ==\n{}",
                            crate::auth::log_text("log.txt", 2000),
                            crate::auth::log_text("overlay.log", 2000)
                        );
                        ui.ctx().copy_text(all);
                        self.status = "Copied the logs to the clipboard".to_string();
                    }
                    if ui.button("Open folder").clicked() {
                        let _ = open::that(data_dir());
                    }
                });
            });
            small_text(
                ui,
                "Everything the launcher does is written here, with a timestamp. If something breaks, press Copy all and send the lines over - they say exactly where it stopped."
                    .to_string(),
            );
            ui.add_space(6.0);
            let mut refresh_logs = false;
            ui.horizontal(|ui| {
                if ui.button("Refresh").clicked() {
                    refresh_logs = true;
                    ui.ctx().request_repaint();
                }
                if ui.button("Clear logs").clicked() {
                    crate::auth::clear_log("log.txt");
                    crate::auth::clear_log("overlay.log");
                    self.logs_view = None;
                    self.logs_view_at = None;
                    refresh_logs = true;
                    self.status = "Cleared the logs".to_string();
                }
            });
            small_text(ui, format!("Folder: {}", data_dir().display()));
            ui.add_space(8.0);

            // The page redraws every frame, so re-reading both files (and their tails)
            // each frame was constant disk I/O. Read them at most once a second, or when
            // Refresh/Clear is pressed, and keep the strings here so they are not cloned
            // back into the cache on every frame either.
            let due = refresh_logs
                || self
                    .logs_view_at
                    .is_none_or(|t| t.elapsed() >= std::time::Duration::from_secs(1));
            let (mut app_text, mut overlay_text) = self.logs_view.take().unwrap_or_default();
            if due {
                app_text = crate::auth::log_text("log.txt", 250);
                overlay_text = crate::auth::log_text("overlay.log", 250);
                self.logs_view_at = Some(std::time::Instant::now());
            }

            for (title, file, text) in [
                ("App log — log.txt", "log.txt", &mut app_text),
                ("Overlay log — overlay.log", "overlay.log", &mut overlay_text),
            ] {
                ui.label(RichText::new(title).size(13.0).strong());
                let mut placeholder;
                let shown: &mut String = if text.trim().is_empty() {
                    placeholder = "(empty)".to_string();
                    &mut placeholder
                } else {
                    text
                };
                egui::Frame::new()
                    .fill(p.surface_bg)
                    .stroke(egui::Stroke::new(1.0, p.border))
                    .corner_radius(8)
                    .inner_margin(egui::Margin::symmetric(10, 8))
                    .show(ui, |ui| {
                        egui::ScrollArea::vertical()
                            .id_salt(("log_view", file))
                            .max_height(220.0)
                            .auto_shrink([false, false])
                            .show(ui, |ui| {
                                // A log tail is kilobytes of text laid out on the CPU. While
                                // the page is being flung that layout buys nothing, so hold
                                // the box at its size and skip it for those frames.
                                if crate::ui::widgets::fast_scrolling(ui) {
                                    ui.allocate_space(egui::vec2(ui.available_width(), 200.0));
                                } else {
                                    ui.add(
                                        egui::TextEdit::multiline(shown)
                                            .font(egui::TextStyle::Monospace)
                                            .desired_width(f32::INFINITY)
                                            .interactive(false),
                                    );
                                }
                            });
                    });
                ui.add_space(8.0);
            }
            // Put the (possibly refreshed) tails back for the next frames.
            self.logs_view = Some((app_text, overlay_text));
        });
    }
}
