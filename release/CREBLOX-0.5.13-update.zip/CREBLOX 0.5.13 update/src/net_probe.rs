//! Round-trip time to the game server the player is actually connected to.
//!
//! A ping is only meaningful against the machine serving the game. Roblox's web edge is in
//! the US and answers in ~125 ms from New Zealand, while the live server in Sydney answers in
//! ~30 ms - so a web probe reports a number that has nothing to do with the session. This
//! module measures the server IP the client log names, in four tiers, and returns `None` when
//! none of them answers, which is what the HUD shows as `-- ms`:
//!
//! 1. **ICMP echo** to that exact IP - what Roblox's native performance stats report.
//! 2. **RakNet `ID_UNCONNECTED_PING`** over the game's own UDP port.
//! 3. **TCP handshake** to the data-centre edge (443, then 80).
//! 4. The public room list's ping for the job (in `game_overlay`, off this thread).
//!
//! Roblox's UDMUX relays drop unauthenticated RakNet pings and often ICMP as well, which left
//! the row at `-- ms` for a whole session; each tier exists because the one above it is
//! filtered by some relay.
//!
//! No image, no egui, no platform APIs: the whole module runs in the VM test harness.

use std::net::{TcpStream, ToSocketAddrs, UdpSocket};
use std::process::Command;
use std::time::{Duration, Instant};

/// RakNet's default game port when the log line carries no port.
pub const DEFAULT_GAME_PORT: u16 = 53_640;

const UDP_TIMEOUT: Duration = Duration::from_millis(400);

/// `00 ff ff 00 fe fe fe fe fd fd fd fd 12 34 56 78`: the offline-message magic RakNet
/// servers expect in an unconnected ping.
const RAKNET_MAGIC: [u8; 16] = [
    0x00, 0xff, 0xff, 0x00, 0xfe, 0xfe, 0xfe, 0xfe, 0xfd, 0xfd, 0xfd, 0xfd, 0x12, 0x34, 0x56, 0x78,
];

/// The 25-byte RakNet `ID_UNCONNECTED_PING`: `0x01`, the 8-byte send time, then the
/// offline-message magic. This is the packet the game's own servers answer, so the measured
/// number is the path the player is on rather than an HTTP round trip somewhere else.
pub fn unconnected_ping(sent_at_ms: u64) -> [u8; 25] {
    let mut ping = [0u8; 25];
    ping[0] = 0x01; // ID_UNCONNECTED_PING
    ping[1..9].copy_from_slice(&sent_at_ms.to_be_bytes());
    ping[9..].copy_from_slice(&RAKNET_MAGIC);
    ping
}

/// `true` for `ID_UNCONNECTED_PONG` (`0x1c`), the only datagram that proves the game server
/// received our ping. A relay (UDMUX) that answers something else must never be timed as if
/// it were the server's round trip.
pub fn is_unconnected_pong(datagram: &[u8]) -> bool {
    // 0x1c + 8-byte time + 8-byte server guid + 16-byte magic is the smallest real pong.
    datagram.len() >= 33 && datagram[0] == 0x1c
}

/// One RakNet `ID_UNCONNECTED_PING` on a connected UDP socket, timed until the matching
/// `ID_UNCONNECTED_PONG` comes back. Datagrams of any other shape are ignored, and the whole
/// exchange gives up after [`UDP_TIMEOUT`] so a silent server costs one tick, not the loop.
/// Returns the RTT, or the reason it produced no number, so the probe can put that in
/// `log.txt` instead of leaving `-- ms` unexplained.
pub fn udp_rtt_traced(ip: &str, port: u16) -> Result<u32, String> {
    let ip = ip.trim();
    if ip.is_empty() {
        return Err("empty address".to_string());
    }
    let addr = (ip, port)
        .to_socket_addrs()
        .map_err(|e| format!("unresolved address ({e})"))?
        .find(|a| a.is_ipv4())
        .ok_or_else(|| "no IPv4 address".to_string())?;
    let sock = UdpSocket::bind("0.0.0.0:0").map_err(|e| format!("bind failed ({e})"))?;
    sock.connect(addr)
        .map_err(|e| format!("connect failed ({e})"))?;

    let now = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map(|d| d.as_millis() as u64)
        .unwrap_or(0);
    let start = Instant::now();
    sock.send(&unconnected_ping(now))
        .map_err(|e| format!("send failed ({e})"))?;
    let deadline = start + UDP_TIMEOUT;
    let timeout = || format!("no pong in {} ms", UDP_TIMEOUT.as_millis());
    let mut buf = [0u8; 512];
    loop {
        let left = deadline
            .checked_duration_since(Instant::now())
            .ok_or_else(|| timeout())?;
        if left.is_zero() {
            return Err(timeout());
        }
        sock.set_read_timeout(Some(left))
            .map_err(|e| format!("read timeout failed ({e})"))?;
        let n = match sock.recv(&mut buf) {
            Ok(n) => n,
            Err(e)
                if matches!(
                    e.kind(),
                    std::io::ErrorKind::WouldBlock | std::io::ErrorKind::TimedOut
                ) =>
            {
                return Err(timeout());
            }
            Err(e) => return Err(format!("recv failed ({e})")),
        };
        if is_unconnected_pong(&buf[..n]) {
            return Ok(start.elapsed().as_millis().clamp(1, 9_999) as u32);
        }
        // Not our answer: keep waiting for the pong until the deadline.
    }
}

/// The ping the public room list reports for one job.
///
/// This is the fallback for a server behind a UDMUX relay that drops unconnected pings: it is
/// the only published number tied to the exact job the player is in, so a job that is not
/// listed yields `None` instead of a stranger's ping.
pub fn ping_for_job(entries: &[(String, Option<u64>)], job_id: &str) -> Option<u32> {
    if job_id.is_empty() {
        return None;
    }
    entries
        .iter()
        .find(|(id, _)| id == job_id)
        .and_then(|(_, ping)| *ping)
        .filter(|ping| *ping > 0)
        .map(|ping| ping.min(9_999) as u32)
}

/// One ICMP echo through the system `ping`, for servers that answer echo but filter TCP and
/// ignore RakNet's unconnected ping.
///
/// This is tier one: Roblox's regional data-centre IPs answer echo over the same path the
/// game uses, so the number matches what the game's own performance stats show. A filtered
/// echo costs the bounded wait below and nothing else.
/// Returns the RTT, or the reason it produced no number (no reply, no tool, exit status).
pub fn icmp_rtt_traced(ip: &str) -> Result<u32, String> {
    let ip = ip.trim();
    if ip.is_empty() {
        return Err("empty address".to_string());
    }
    let Some(mut cmd) = ping_command(ip) else {
        return Err("no icmp tool on this platform".to_string());
    };
    let out = cmd
        .output()
        .map_err(|e| format!("ping could not run ({e})"))?;
    if !out.status.success() {
        return Err(match out.status.code() {
            Some(code) => format!("no echo reply (ping exit {code})"),
            None => "no echo reply (ping killed)".to_string(),
        });
    }
    parse_ping_time(&String::from_utf8_lossy(&out.stdout))
        .ok_or_else(|| "unparsable ping output".to_string())
}

#[cfg(target_os = "macos")]
fn ping_command(ip: &str) -> Option<Command> {
    use std::process::Stdio;
    let mut cmd = Command::new("/sbin/ping");
    // `-W` is the per-reply wait in milliseconds and `-t` bounds the whole run, so a relay
    // that drops echo can never hold the probe thread; `-n` keeps it numeric (no reverse DNS
    // on an address that may be dead) and stdin is closed so the child never waits on us.
    cmd.args(["-n", "-c", "1", "-W", "800", "-t", "1", ip])
        .stdin(Stdio::null())
        .stderr(Stdio::null());
    Some(cmd)
}

#[cfg(target_os = "windows")]
fn ping_command(ip: &str) -> Option<Command> {
    use std::os::windows::process::CommandExt;
    use std::process::Stdio;
    const CREATE_NO_WINDOW: u32 = 0x0800_0000;
    let mut cmd = Command::new("ping");
    cmd.args(["-n", "1", "-w", "800", ip])
        .creation_flags(CREATE_NO_WINDOW)
        .stdin(Stdio::null())
        .stderr(Stdio::null());
    Some(cmd)
}

#[cfg(not(any(target_os = "macos", target_os = "windows")))]
fn ping_command(_ip: &str) -> Option<Command> {
    None
}

/// Ports a Roblox data-centre edge answers even when it filters ICMP and RakNet: the HTTP(S)
/// listeners in front of the same machines that host the game server.
pub const TCP_PROBE_PORTS: [u16; 2] = [443, 80];

/// How long one handshake may take before the next port is tried.
const TCP_TIMEOUT: Duration = Duration::from_millis(400);

/// Tier three: the TCP handshake RTT to the same IP.
///
/// UDMUX relays drop unauthenticated RakNet pings, and some drop ICMP too, but the edge in
/// front of the server still completes a handshake - and a handshake is a real round trip
/// over the player's path, not a web request to another continent. `None` when no port
/// answers, so the row falls through to the room list instead of inventing a number.
/// Returns the RTT, or the reason it produced no number, one word per port tried.
pub fn tcp_rtt_traced(ip: &str, ports: &[u16]) -> Result<u32, String> {
    let ip = ip.trim();
    if ip.is_empty() {
        return Err("empty address".to_string());
    }
    if ports.is_empty() {
        return Err("no port to try".to_string());
    }
    // Resolve once for every port: a dead address is not looked up again per port.
    let addrs = (ip, ports[0])
        .to_socket_addrs()
        .map_err(|e| format!("unresolved address ({e})"))?;
    let ip = addrs
        .map(|a| a.ip())
        .find(|ip| ip.is_ipv4())
        .ok_or_else(|| "no IPv4 address".to_string())?;
    let mut tried = Vec::new();
    for port in ports {
        let addr = std::net::SocketAddr::new(ip, *port);
        let start = Instant::now();
        match TcpStream::connect_timeout(&addr, TCP_TIMEOUT) {
            Ok(_) => return Ok(start.elapsed().as_millis().clamp(1, 9_999) as u32),
            Err(e) => tried.push(format!("{port} {}", tcp_reason(&e))),
        }
    }
    Err(tried.join(", "))
}

/// One word for a failed handshake, short enough to read inside a log line.
fn tcp_reason(error: &std::io::Error) -> &'static str {
    match error.kind() {
        std::io::ErrorKind::ConnectionRefused => "refused",
        std::io::ErrorKind::TimedOut | std::io::ErrorKind::WouldBlock => "timeout",
        std::io::ErrorKind::PermissionDenied => "blocked",
        std::io::ErrorKind::NetworkUnreachable => "unreachable",
        std::io::ErrorKind::HostUnreachable => "unreachable",
        _ => "failed",
    }
}

/// Which tier produced a number, and that number.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct ProbeOutcome {
    /// `icmp`, `raknet` or `tcp`.
    pub via: &'static str,
    pub ms: u32,
}

/// Why one whole probe run had no number: the tier the chain gave up on, plus one reason per
/// tier in the order they were tried.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ProbeMiss {
    /// The last tier tried, which is what the HUD names after `-- ms`.
    pub last: &'static str,
    pub reasons: Vec<String>,
}

/// Runs every network tier in the shipping order and returns the first number, or every
/// reason it had none.
///
/// This is the exact chain the overlay runs on its probe thread (an integration test in
/// `vm-tests` drives it against local mock relays), so the order cannot drift between what
/// ships and what is tested: ICMP, then the RakNet unconnected ping, then a TCP handshake.
/// `tcp_ports` is passed in so the caller chooses what an edge can accept; the overlay uses
/// [`TCP_PROBE_PORTS`].
pub fn probe_server(ip: &str, port: u16, tcp_ports: &[u16]) -> Result<ProbeOutcome, ProbeMiss> {
    let mut reasons = Vec::new();
    match icmp_rtt_traced(ip) {
        Ok(ms) => return Ok(ProbeOutcome { via: "icmp", ms }),
        Err(why) => reasons.push(format!("icmp {why}")),
    }
    match udp_rtt_traced(ip, port) {
        Ok(ms) => return Ok(ProbeOutcome { via: "raknet", ms }),
        Err(why) => reasons.push(format!("raknet {why}")),
    }
    match tcp_rtt_traced(ip, tcp_ports) {
        Ok(ms) => return Ok(ProbeOutcome { via: "tcp", ms }),
        Err(why) => reasons.push(format!("tcp {why}")),
    }
    Err(ProbeMiss {
        last: "tcp",
        reasons,
    })
}

/// The one `log.txt` line per probe run: the target, the result, and - when there is no
/// number - every tier's reason. Kept next to [`probe_server`] so the log text a support
/// report quotes is the same text the integration test asserts.
pub fn probe_line(
    target: &str,
    rtt: Option<u32>,
    source: Option<&str>,
    misses: &[String],
) -> String {
    match (rtt, source) {
        (Some(ms), Some(source)) => format!("overlay: ping probe {target} -> {ms} ms ({source})"),
        (Some(ms), None) => format!("overlay: ping probe {target} -> {ms} ms"),
        (None, _) => format!(
            "overlay: ping probe {target} -> none ({})",
            misses.join("; ")
        ),
    }
}

/// `time=30.4 ms` (macOS), `time=30ms` / `time<1ms` (Windows).
pub fn parse_ping_time(text: &str) -> Option<u32> {
    let idx = text.find("time")?;
    let rest = &text[idx + 4..];
    let eq = rest.find(['=', '<'])?;
    let num: String = rest[eq + 1..]
        .trim_start()
        .chars()
        .take_while(|c| c.is_ascii_digit() || *c == '.')
        .collect();
    let ms = num.parse::<f32>().ok()?;
    Some(ms.round().max(1.0) as u32)
}
