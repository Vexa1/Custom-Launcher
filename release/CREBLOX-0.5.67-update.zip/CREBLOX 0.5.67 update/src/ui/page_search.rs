use crate::app::Creblox;
use crate::theme::RED;
use crate::types::Action;
use crate::ui::widgets::*;
use eframe::egui::{self, RichText};

impl Creblox {
    pub fn page_search(&mut self, ui: &mut egui::Ui, acts: &mut Vec<Action>) {
        ui.add_space(10.0);
        ui.label(
            RichText::new(format!("Results for \"{}\"", self.searched))
                .size(24.0)
                .strong(),
        );
        ui.add_space(10.0);
        if self.searching {
            ui.horizontal(|ui| {
                ui.spinner();
                ui.label("Searching...");
            });
        }
        match &self.results {
            Some(Err(e)) => {
                ui.colored_label(crate::theme::text_ink(ui, RED), e);
            }
            Some(Ok(v)) if v.is_empty() => {
                ui.label("No games found.");
            }
            Some(Ok(v)) => {
                let preview = self.current_card_preview();
                wide_grid(ui, v, &self.wide, preview, &self.playtime, acts);
            }
            None => {
                if !self.searching {
                    ui.label("Type something in the search box to find games.");
                }
            }
        }
        ui.add_space(20.0);
    }
}
