<div align="center">
  <img src="assets/logo.png" alt="CREBLOX" width="104" height="104" />
  <h1>CREBLOX</h1>
  <p><strong>A fast, native Roblox launcher and in-game overlay written in Rust.</strong></p>
  <p>Built for macOS 10.15.7 Catalina on Intel Macs, and it still runs on newer Macs.</p>
</div>

---

## What this is

CREBLOX is two things:

1. **A native launcher** (`egui`/`eframe`, OpenGL `glow` renderer) for browsing and
   launching Roblox games. It never boots the 3D engine just to browse: you sign
   in, browse Home / Charts / Search, open profiles, manage friends, tune
   FastFlags, then launch the official Roblox client.
2. **In-game overlays** that float over the *Roblox window itself*, including a
   fullscreen Space: server region, live stats (CPU / RAM / live ping / session /
   clock / FPS cap), the active FastFlags, game info and a crosshair. The overlay
   only appears while Roblox is the app in front.

The overlay is a second, tiny copy of CREBLOX running as a transparent,
click-through window kept exactly on top of the Roblox window and drawn with
`egui`. Nothing is injected into Roblox, no game memory is touched, and it asks
for no accessibility or screen-recording permission.

## The in-game overlays

Each panel can be switched on separately, placed in any of the four corners and
styled with its own opacity.

| Panel | What it shows |
| --- | --- |
| Server | The datacenter's city and country (Roblox's player log records the IP it joined; CREBLOX geolocates it once over HTTPS and caches the answer), plus the IP and Job ID. |
| Stats | CPU and RAM of the Roblox process, live ping to the server (a TCP round trip, with Roblox's web edge as fallback), session timer, local clock, the current FPS cap and an optional on-switch for Roblox's own accurate FPS counter. |
| FastFlags | Every FastFlag CREBLOX writes to Roblox, so you can see what is active. |
| Game | Game name, place ID, players online and time in the server. |
| Crosshair | Dot, cross, circle or cross + dot, with size, thickness, gap, colour, opacity and X/Y offset. |
| Server badge | A small "Connected server" card in the launcher window with a Copy Job ID button. |

Ping is measured with `/sbin/ping`, process load with `/bin/ps` — a couple of
short-lived system tools a second, nothing more. Setting *Close the CREBLOX
window while I play* only hides the window: CREBLOX itself keeps running in the
menu bar, so the tray icon, the overlays and the settings stay available during
the game and nothing has to start up again. The window comes back by itself when
you leave the game.

Everything is configured in **Settings → In-Game Overlay & Launch Behavior**,
in the **Animations & Performance** card (smooth transitions, animated
backgrounds, video previews) and in the launcher's FastFlags page.

## The menu bar

CREBLOX lives in the menu bar while it runs, so it can be opened over a game at any
time — including a fullscreen Roblox Space:

* **Open CREBLOX** brings the launcher to the front (the app is activated, so
  macOS switches to CREBLOX's Space instead of leaving it behind Roblox)
* **Home / Profile / Avatar / Notifications / Settings… / FastFlags…** jump
  straight to that page
* **Playing: <game>** and **Server: <region>** show what you are connected to,
  and **Copy Job ID** copies it
* **Server region overlay / Stats overlay / Crosshair** toggle the in-game
  panels and crosshair live, without leaving the game
* Discord Rich Presence, Check for Updates… and Quit CREBLOX

The launcher keeps running while you play (capped at ~190 MB) so the menu bar is
always there. If you would rather free that memory, turn on *Close the launcher
while I play and reopen it when I leave* — the overlays then run in a tiny
headless helper instead.

## Requirements

* macOS 10.15 (Catalina) or newer. The build sets
  `MACOSX_DEPLOYMENT_TARGET=10.15`.
* Intel or Apple Silicon. CREBLOX uses the OpenGL (`glow`) renderer, the most
  compatible choice on 2012-era Intel GPUs.
* Roblox Player installed once from [roblox.com](https://www.roblox.com)
  (`/Applications/Roblox.app`).
* To build: [Rust](https://rustup.rs) (stable) and Xcode Command Line Tools
  (`xcode-select --install`).

## Build and run

Fastest way: double-click **Build CREBLOX.command** in the extracted folder. It
builds an optimised release binary, generates the `.icns` from
`assets/logo.png`, writes `Info.plist` (10.15 minimum), ad-hoc signs the bundle
and installs it to `~/Applications` (or `/Applications` when writable).

Or from Terminal:

```bash
./scripts/build-macos-app.sh
open dist/CREBLOX.app
```

For development: `cargo run` (a plain binary, no bundle).

## GitHub release downloads

Every release publishes two packages:

* **`creblox-<version>-macos-full.zip`** — the complete project for a fresh
  install, including assets and **Build CREBLOX.command**. This is a source
  package, not a prebuilt binary; macOS builds it locally with Rust and Xcode
  Command Line Tools.
* **`creblox-update-<version>-macos.zip`** — the small in-place update. It
  contains the source and updater files only, with no assets, no second copy of
  the project and no `build.rs`, so there is much less to download.

For an existing install, unzip the update anywhere and double-click **Update
CREBLOX.command**. It finds the CREBLOX folder you already have (or the path it
saved during your last build), copies the new files over it, deletes files this
version no longer uses, then rebuilds and installs over the app you are running.
In Terminal the same thing is:

```bash
bash scripts/update-macos.sh
```

If you keep several copies of the source around, the most recently used one wins.
If none can be found, the window tells you to drag the update folder's contents
into your CREBLOX folder and double-click **Build CREBLOX.command** instead.

Your settings, saved accounts and logins live in
`~/Library/Application Support/CREBLOX` and are untouched, so there is nothing to
re-enter and no old folder to delete first.

## Performance notes

Everything here is an internal optimisation: no setting or feature changes.

* The theme palette is cached behind a generation counter instead of being read
  out of the egui context hundreds of times per frame.
* The overlay window only re-reads and re-parses its spec file when the file
  actually changed (size + modification time), instead of four times a second.
* The "is the window on screen" flag the idle animation pacer uses is only
  written when it changes, not on every frame.
* Repaints are paced (5 s focused, 20 s in the background, 30 s hidden) so a
  hidden or idle launcher uses essentially no CPU.
* The old sidebar FPS/RAM/CPU dock and its sampler/painters were removed (the
  stats live in the in-game overlay now), cutting about 1,400 lines of code the
  app no longer has to carry.
* `setpriority` is only called when the CPU-limit level actually changes.

## What works on macOS

| Feature | Implementation |
| --- | --- |
| Quick Login / saved accounts | Roblox Quick Login; sessions encrypted with AES-256-GCM, per-install key stored with `0600` permissions |
| Browse, charts, search, favourites, servers | Roblox web APIs |
| Launch games | Authenticated `roblox-player:` ticket through LaunchServices |
| FastFlags / target FPS | `~/Library/Preferences/com.roblox.Roblox/ClientAppSettings.json` and the in-bundle settings file when writable |
| Renderer choice | Automatic / Metal / OpenGL (Direct3D and Vulkan hidden on macOS) |
| In-game overlays | Transparent click-through window above Roblox (also fullscreen), CoreGraphics window lookup |
| Menu bar tray | Native `NSStatusItem` menu: open/hide CREBLOX, Home, Profile, Avatar, Notifications, Settings, FastFlags, overlay toggles, server + Job ID, Discord RPC, updates, quit |
| Start at login | `~/Library/LaunchAgents/com.creblox.launcher.plist` |
| Auto-close leftover Roblox | Finds `RobloxPlayer` processes with `libproc` and sends `SIGKILL` once the session ends |
| Live stats | `ps`, `ping` and `libproc` — shown in the in-game panels, not in the launcher |
| Discord Rich Presence | Discord's `discord-ipc-N` Unix socket in `$TMPDIR` |

## Where data lives

Everything is in `~/Library/Application Support/CREBLOX`:

* `settings.json`, `fastflags.json`, `accounts.dat`, `session.dat`
* `log.txt`, `session.key` (owner-only), `seen_notifications.json`
* `server_regions.json` — the cached datacenter → city lookups

Saved settings from an older install folder are copied over once, on first run.

## Notes and limits

* **Region names are approximate.** Roblox routes through edge datacenters, and
  the free geolocation service can only name the city it associates with the
  address. Turn *Online region lookup* off and the overlay shows the raw
  datacenter IP instead — nothing leaves your Mac in that mode.
* **Troubleshooting the overlay:** `~/Library/Application Support/CREBLOX/overlay.log`
  records when the overlay window started, whether it found the Roblox window and
  where it placed itself. If an overlay never appears, that file says why.
* **Background cleanup waits for the game to end.** A Roblox process launched for a game
  is protected while the game is starting, then closed as soon as the player log reports
  that the session ended (`returnToLuaApp` / `Entered app session.`). A process whose log
  cannot be read is only closed when it can positively be identified as the app/home
  screen (or one launched explicitly to the tray), so a running session is never killed.
* **Server detection relies on the player log.** `~/Library/Logs/Roblox` has to
  be readable. If Roblox changes its log format, the overlay falls back to
  "Waiting for a server" instead of showing a wrong region.
* **This is a local build.** The updater checks nothing upstream; update with
  the `creblox-update-<version>-macos.zip` package. Roblox itself updates on its own.
* **CPU limiter:** macOS has no per-process CPU quota for unprivileged apps, so
  the limiter lowers scheduling priority (niceness) instead of hard capping it.
  The RAM cap limits CREBLOX's own caches.
* **Overlay on Windows/Linux:** the overlay is macOS-only; the launcher still
  builds elsewhere and the settings card explains that.

## License

GPL-3.0-only — see [LICENSE](LICENSE). This project is a heavily modified fork of
an open-source (GPL-3.0) Roblox launcher; the original copyright notices are
kept in `LICENSE` as the license requires.
